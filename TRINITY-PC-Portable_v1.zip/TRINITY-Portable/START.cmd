@echo off
start "" "%~dp0TRINITY.html"
