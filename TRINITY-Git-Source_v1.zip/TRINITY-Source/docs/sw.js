const BASE=new URL('./',self.location.href),CACHE='trinity-v4.1.0:'+BASE.href;
const SHELL=['','index.html','style.css','main.js','engine.js','maps.js','catalog.js','expansion-ui.js','art/units.webp','renderer.js','network.js','install.js','runtime.js','manifest.webmanifest','icons/icon-192.png','icons/icon-512.png','icons/maskable-512.png','icons/apple-touch-icon.png'];
const URLS=SHELL.map(path=>new URL(path,BASE).href);
self.addEventListener('install',event=>event.waitUntil(caches.open(CACHE).then(cache=>cache.addAll(URLS.map(url=>new Request(url,{cache:'reload'}))))));
self.addEventListener('activate',event=>event.waitUntil(Promise.all([caches.keys().then(keys=>Promise.all(keys.filter(key=>key.startsWith('trinity-v')&&key.endsWith(':'+BASE.href)&&key!==CACHE).map(key=>caches.delete(key)))),self.clients.claim()])));
self.addEventListener('fetch',event=>{
 const request=event.request,url=new URL(request.url);
 if(request.method!=='GET'||url.origin!==BASE.origin||!url.pathname.startsWith(BASE.pathname)||url.pathname.startsWith('/api/'))return;
 if(request.mode==='navigate'){event.respondWith(fetch(request).then(response=>{if(!response.ok)throw new Error('Offline');return response;}).catch(()=>caches.match(new URL('index.html',BASE).href)));return;}
 if(URLS.includes(url.href))event.respondWith(caches.open(CACHE).then(async cache=>(await cache.match(url.href))||fetch(request)));
});
