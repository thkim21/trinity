// Fixed, authored terrain layouts. All maps support 2–8 players.
export const STARTS=[{x:430,y:1500},{x:300,y:870},{x:480,y:290},{x:1170,y:260},{x:1900,y:320},{x:2080,y:990},{x:1880,y:1640},{x:1160,y:1730}];
export const BIOMES={
 forest:{ground:'#526248',road:'#82785b',edge:'#8b9b73',water:'#284d50',accent:'#9bbf76'},
 desert:{ground:'#857050',road:'#b19a6b',edge:'#cfb78c',water:'#473b35',accent:'#efd08d'},
 ice:{ground:'#587681',road:'#91aab1',edge:'#d0e2e5',water:'#264757',accent:'#a3e5ef'},
 lava:{ground:'#50443e',road:'#786254',edge:'#a56d4c',water:'#a73e24',accent:'#ffb16e'},
 crystal:{ground:'#554d6a',road:'#80748c',edge:'#b9a8cc',water:'#403858',accent:'#d4acf0'},
 industrial:{ground:'#505e61',road:'#808581',edge:'#a5aa98',water:'#293b43',accent:'#96ccd2'},
 dusk:{ground:'#555767',road:'#7c7882',edge:'#a5a1b9',water:'#333e5e',accent:'#abbbef'},
 coast:{ground:'#4f6e62',road:'#99a47f',edge:'#b7c6a2',water:'#225d70',accent:'#82d8d2'}
};
const obstacle=([x,y,rx,ry])=>({x,y,rx,ry});
const map=(id,name,en,biome,style,description,obstacles,expansions,highgrounds=[],rich=2600)=>({id,name,en,biome,style,description,obstacles:obstacles.map(obstacle),expansions:expansions.map(([x,y,kind='ore'])=>({x,y,kind,amount:rich})),highgrounds:highgrounds.map(([x,y,rx,ry])=>({x,y,rx,ry})),players:'2–8명'});
export const MAPS=[
 map('basin','잊힌 분지','FORGOTTEN BASIN','forest','균형형','호수 사이 넓은 우회로. 초반 운영과 다방향 공격을 익히기 좋은 전장.',[[1190,1000,172,128],[1030,670,105,135],[980,1500,100,65],[1630,360,115,105]],[[450,900],[1570,1540,'crystal'],[1480,740],[750,1760,'crystal'],[2080,510],[780,1100,'crystal']]),
 map('narrow-gate','강철 관문','IRON GATE','industrial','병목형','중앙의 세 관문과 외곽 우회로. 창병으로 좁은 입구를 지키고 공성포로 돌파하세요.',[[1190,600,170,100],[1190,880,160,90],[1190,1170,160,90],[1190,1430,150,75]],[[850,800],[1550,1200],[850,1200,'crystal'],[1550,800,'crystal']],[[810,1000,180,210],[1570,1000,180,210]]),
 map('four-passes','네 개의 고개','FOUR PASSES','forest','고지형','네 고지가 중앙 진입로를 내려다봅니다. 원거리 병력으로 고지를 먼저 점령하세요.',[[950,760,110,110],[1450,760,110,110],[950,1240,110,110],[1450,1240,110,110]],[[1200,1000,'crystal'],[720,1000],[1680,1000]],[[780,680,155,140],[1640,680,155,140],[780,1360,155,140],[1640,1360,155,140]]),
 map('broken-ring','균열 고리','FRACTURED RING','crystal','다중 진입','여섯 균열 사이로 병력이 드나듭니다. 중앙 수정 지대를 차지하려면 여러 입구를 지켜야 합니다.',[[980,770,100,85],[1250,680,100,85],[1510,850,100,85],[1430,1190,100,85],[1180,1350,100,85],[900,1150,100,85]],[[1190,1010,'crystal'],[720,600],[1760,1400],[700,1370],[1730,590]],[],3600),
 map('gold-rush','황금 쟁탈지','GOLD RUSH','desert','자원 집중','중앙에 풍부한 광석이 몰려 있습니다. 자원 선점과 일꾼 호위가 승부를 가릅니다.',[[870,720,100,160],[1520,1300,100,150],[1510,700,100,110],[850,1270,100,110]],[[1070,980],[1300,970],[1190,1130],[750,1000,'crystal'],[1700,1000,'crystal']],[],4200),
 map('ice-bridge','얼어붙은 회랑','FROZEN CORRIDOR','ice','좁은 회랑','두 빙하 사이의 가로 회랑. 정면 화력과 바깥쪽 기동 공격을 함께 운용하세요.',[[860,790,145,125],[1190,790,145,125],[1520,790,145,125],[860,1210,145,125],[1190,1210,145,125],[1520,1210,145,125]],[[920,1000],[1430,1000,'crystal'],[710,1450],[1740,560]]),
 map('lava-fork','불꽃 삼거리','EMBER FORK','lava','갈림길','S자 용암 지대가 진군로를 나눕니다. 중앙 수정과 양쪽 우회로에 정찰을 배치하세요.',[[990,850,240,130],[1400,1160,225,145],[1430,650,135,75]],[[1270,970,'crystal'],[720,1180],[1660,840],[780,520,'crystal'],[1650,1500]]),
 map('crossroads','사거리 전초전','CROSSROADS','industrial','중앙 교전','네 폐쇄 구역 사이 십자 통로. 중앙 교차점을 점유하면 여러 방향으로 압박할 수 있습니다.',[[930,770,160,135],[1470,770,160,135],[930,1230,160,135],[1470,1230,160,135]],[[1200,600],[1200,1400],[720,1000,'crystal'],[1690,1000,'crystal']],[[1200,1000,130,120]]),
 map('twin-forts','쌍둥이 요새','TWIN FORTS','desert','거점 분할','양쪽 고지를 사이에 둔 요새전. 중앙 능선을 우회해 상대의 후방을 압박하세요.',[[1200,920,130,250],[1200,1400,140,80]],[[800,920],[1590,1100],[840,1230,'crystal'],[1550,770,'crystal']],[[810,970,220,180],[1600,1010,220,180]]),
 map('long-march','긴 행군','LONG MARCH','coast','우회형','거대한 중앙 바다가 직선 진군을 막습니다. 기동병의 속도와 정찰이 중요합니다.',[[1200,1000,380,280]],[[730,760],[1670,1240],[850,1430,'crystal'],[1580,550,'crystal']]),
 map('prism-garden','프리즘 정원','PRISM GARDEN','crystal','산개 지형','흩어진 수정 암반 사이로 소규모 부대가 기습합니다. 병력을 나누어 자원 지대를 지키세요.',[[840,720,75,95],[1100,650,70,75],[1480,720,70,95],[970,960,80,85],[1360,1010,85,100],[810,1250,85,75],[1150,1350,75,80],[1520,1300,75,85]],[[1180,950,'crystal'],[1180,1150,'crystal'],[670,1020],[1750,950]],[],3200),
 map('red-canyon','붉은 협곡','RED CANYON','lava','지그재그','길게 뻗은 절벽 끝을 돌아 전진합니다. 느린 공성 부대는 호위가 필요합니다.',[[1080,770,300,85],[1330,1030,300,80],[1070,1320,290,80]],[[1540,650],[820,1050,'crystal'],[1510,1400],[1220,900,'crystal']]),
 map('wind-wall','바람 장벽','WIND WALL','ice','세로 통로','세로로 뻗은 빙벽이 긴 사격 통로를 만듭니다. 옆 통로를 통한 포위를 경계하세요.',[[880,970,90,230],[1200,800,85,170],[1530,1130,85,230]],[[1080,1170],[1390,800],[710,1360,'crystal'],[1740,650,'crystal']],[[1300,1390,170,110]]),
 map('moon-crater','달의 분화구','LUNAR CRATER','dusk','외곽 거점','중앙 분화구를 네 자원 거점이 둘러쌉니다. 외곽 점령으로 경제 우위를 확보하세요.',[[1200,1000,250,210],[820,640,100,70],[1590,1360,100,70]],[[820,950],[1570,1030],[1200,660,'crystal'],[1200,1350,'crystal']],[[760,1140,140,150],[1640,850,140,150]]),
 map('tidal-isles','조수 군도','TIDAL ISLES','coast','연결 지형','물길 사이 육지 통로가 연결된 군도입니다. 좁은 연결부와 풍부한 바깥 광맥을 활용하세요.',[[880,790,150,120],[1340,700,190,100],[1160,1130,170,130],[1590,1260,140,100]],[[800,1130],[1510,970,'crystal'],[780,1450],[1700,700,'crystal'],[1170,890]],[],3100),
 map('citadel','최후의 성채','LAST CITADEL','dusk','중앙 고지','네 능선이 중앙 성채를 감쌉니다. 고지 화력과 고급 유닛을 조합해 성채를 점령하세요.',[[900,840,130,95],[1490,840,130,95],[920,1210,130,95],[1490,1210,130,95],[1200,620,100,65],[1200,1430,100,65]],[[1190,920,'crystal'],[1180,1130],[710,1000],[1730,1000]],[[1200,1020,180,165]],3400)
];
export const DEFAULT_MAP='basin';
export const getMap=id=>MAPS.find(m=>m.id===id)||MAPS[0];
export const validMap=id=>MAPS.some(m=>m.id===id);
export function mapStarts(mapId,count,multiplayer=true){if(mapId==='basin'&&!multiplayer)return [{x:430,y:1500},{x:520,y:370},{x:1890,y:950}];return Array.from({length:count},(_,i)=>({...STARTS[Math.floor(i*8/count)]}));}
export function drawMapPreview(canvas,mapId,count=8){
 const map=getMap(mapId),p=BIOMES[map.biome],c=canvas.getContext('2d'),w=canvas.width,h=canvas.height,sx=w/2400,sy=h/2000;
 c.fillStyle=p.ground;c.fillRect(0,0,w,h);c.strokeStyle=p.edge+'40';c.lineWidth=1;for(let x=0;x<w;x+=w/12){c.beginPath();c.moveTo(x,0);c.lineTo(x,h);c.stroke();}for(let y=0;y<h;y+=h/10){c.beginPath();c.moveTo(0,y);c.lineTo(w,y);c.stroke();}
 for(const zone of map.highgrounds){c.fillStyle=p.accent+'60';c.strokeStyle=p.accent;c.beginPath();c.ellipse(zone.x*sx,zone.y*sy,zone.rx*sx,zone.ry*sy,0,0,Math.PI*2);c.fill();c.stroke();}
 for(const o of map.obstacles){c.fillStyle=p.water;c.beginPath();c.ellipse(o.x*sx,o.y*sy,o.rx*sx,o.ry*sy,0,0,Math.PI*2);c.fill();}
 for(const e of map.expansions){c.fillStyle=e.kind==='crystal'?'#d1a1ff':'#f2d17b';c.fillRect(e.x*sx-3,e.y*sy-3,6,6);}
 mapStarts(map.id,count,count!==3).forEach((base,i)=>{c.fillStyle='#f0f4f2';c.beginPath();c.arc(base.x*sx,base.y*sy,5,0,Math.PI*2);c.fill();c.fillStyle='#0f2028';c.textAlign='center';c.textBaseline='middle';c.font='bold 8px sans-serif';c.fillText(String(i+1),base.x*sx,base.y*sy+.5);});
}
