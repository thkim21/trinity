// Build targets: server (full multiplayer), static (Pages/PWA), offline (one HTML).
export const MODE=globalThis.TRINITY_MODE||'server';
export const ONLINE_ENABLED=MODE==='server'&&/^https?:$/.test(location.protocol);
export const WEB_URL=/^https?:$/.test(location.protocol)?new URL('./',location.href).href:'';
