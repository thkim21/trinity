export const STAGES=['','I','II','III'];
export const PROFILES=[
 {
  worker:{name:'개척 정비사',trait:'중장갑 작업복으로 기지를 건설하고 자원을 운반합니다.'},
  pike:{name:'방벽 창기병',trait:'방벽 장갑 +3. 기동병을 막는 전열의 중심.',armor:3},
  ranger:{name:'레일 저격수',trait:'세 번째 사격은 피해 +40%. 긴 전투에 강합니다.',ability:'precision'},
  rider:{name:'벡터 기병',trait:'추진 엔진: 기본 기동병보다 이동 속도 +15%.',speed:1.15},
  siege:{name:'몰러 자주포',trait:'포탄이 60 범위의 적에게 30% 추가 폭발 피해.',ability:'splash',splash:60},
  support:{name:'리벳 정비기',trait:'150 범위에서 부상당한 아군 하나를 초당 12 회복.',heal:12,targets:1},
  titan:{name:'아틀라스 요새',trait:'장갑 +4. 건물에도 피해 +40%를 주는 강습 기체.',armor:4,ability:'breach'}
 },
 {
  worker:{name:'채집 일벌',trait:'살아 있는 집게로 자원을 채집하고 군락을 확장합니다.'},
  pike:{name:'가시 수호충',trait:'유닛을 타격하면 실제 피해의 20%만큼 체력 흡수.',ability:'leech'},
  ranger:{name:'침 분사충',trait:'공격한 유닛에 3초 동안 초당 3의 독 피해.',ability:'poison'},
  rider:{name:'갈퀴 추적자',trait:'연속 할퀴기: 공격 간격 15% 감소.',rate:.85},
  siege:{name:'산성 포격충',trait:'공격한 유닛에 4초 동안 초당 6의 산성 피해.',ability:'acid'},
  support:{name:'생명의 보모',trait:'150 범위에서 부상당한 아군 최대 3기를 각각 초당 5 회복.',heal:5,targets:3},
  titan:{name:'거대 뿔지배자',trait:'기본 타이탄보다 체력 +20%. 유닛 타격 피해의 20% 흡수.',hp:1.2,ability:'leech'}
 },
 {
  worker:{name:'빛길 조율사',trait:'에너지 도구로 자원을 채집하고 성휘 구조물을 소환합니다.'},
  pike:{name:'쌍광 파수꾼',trait:'강화 보호막: 최대 체력의 36%를 보호막으로 보유.',shield:.36},
  ranger:{name:'프리즘 궁수',trait:'굴절 화살이 상대 장갑 2를 무시합니다.',pierce:2},
  rider:{name:'섬광 유영자',trait:'부유 칼날로 기본 사거리보다 30 멀리 공격.',range:30},
  siege:{name:'공허 수정포',trait:'집속 수정으로 기본 사거리보다 45 멀리 포격.',range:45},
  support:{name:'후광 예언자',trait:'아군 하나를 초당 6 회복하고 보호막도 초당 14 복구.',heal:6,shieldHeal:14,targets:1},
  titan:{name:'천체 집정관',trait:'65 범위에 30% 광역 피해. 최대 체력의 30% 보호막.',shield:.30,ability:'splash',splash:65}
 }
];
export const RESEARCH={
 weapons:{name:'무기 체계',desc:'유닛 공격력 단계당 +12%',building:'foundry',tier:2,max:3,ore:130,crystal:65,time:25,key:'W'},
 armor:{name:'방어 체계',desc:'유닛 장갑 단계당 +2',building:'foundry',tier:2,max:3,ore:120,crystal:60,time:25,key:'E'},
 optics:{name:'장거리 조준',desc:'원거리 유닛 사거리 +15%',building:'foundry',tier:2,max:1,ore:180,crystal:100,time:30,key:'R'},
 logistics:{name:'채집 최적화',desc:'단계당 채집량 +25%, 운반량 +4',building:'academy',tier:1,max:2,ore:120,crystal:40,time:22,key:'W'},
 mobility:{name:'기동 체계',desc:'모든 유닛 이동 속도 +12%',building:'relay',tier:2,max:1,ore:150,crystal:80,time:25,key:'W'},
 fieldcare:{name:'야전 복구',desc:'지원 유닛의 체력·보호막 회복 +40%',building:'relay',tier:2,max:1,ore:160,crystal:100,time:28,key:'E'},
 aegis:{name:'이지스 합금',desc:'철혈 유닛 장갑 +3',building:'academy',tier:3,max:1,ore:260,crystal:180,time:40,faction:0,key:'E'},
 frenzy:{name:'군락 신경망',desc:'군락 유닛 공격 속도 +20%',building:'academy',tier:3,max:1,ore:240,crystal:160,time:40,faction:1,key:'E'},
 resonance:{name:'성휘 공명',desc:'성휘 유닛 최대 보호막 +50%',building:'academy',tier:3,max:1,ore:280,crystal:180,time:40,faction:2,key:'E'}
};
export const COUNTERS={pike:{rider:1.4},rider:{ranger:1.4,support:1.4},ranger:{pike:1.4},siege:{titan:1.5},titan:{pike:1.4}};
export const PORTRAIT_TYPES=['pike','ranger','rider','siege','support','titan'];
export const PORTRAIT_ROWS=[0,234,449,662,890,1118,1536];
export const PORTRAIT_COLS=[0,341,683,1024];
export const ART_URL='./art/units.webp';
