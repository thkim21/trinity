# Git 업로드와 서비스 배포

## 1. Git 저장소에 올리기

ZIP 자체를 올리지 말고 압축을 푼 `TRINITY-Source` 폴더의 내용을 올리세요. `package.json`, `public/`, `server/`, `docs/`가 저장소 최상위에 있도록 합니다. 기존 저장소의 파일을 덮어쓰지 않으려면 새 빈 저장소를 만드세요.

GitHub에서 README 없이 빈 저장소를 만든 뒤, 로컬 폴더에서 아래 명령을 실행합니다. 마지막 URL은 본인의 저장소 주소로 바꾸세요.

```sh
git init
git add .
git commit -m "Add TRINITY FRONTIER"
git branch -M main
git remote add origin https://github.com/YOUR_ACCOUNT/YOUR_REPOSITORY.git
git push -u origin main
```

Git 인증은 본인 계정의 설정을 사용합니다. `node_modules/`, 데이터베이스, `.env`는 업로드 대상에서 제외되어 있습니다.

## 2. 가장 간단한 웹 게시: GitHub Pages (AI 대전)

1. 저장소에 포함된 `docs/` 폴더를 함께 push합니다.
2. 저장소 **Settings → Pages**에서 **Deploy from a branch**를 선택합니다.
3. 브랜치를 **main**, 폴더를 **/docs**로 선택하고 Save를 누릅니다.
4. Pages 설정 화면에 표시된 게시 주소로 접속합니다.

PC·모바일 AI 대전과 PWA를 지원합니다. 사이트 주소가 `/저장소명/` 아래에 있어도 파일·이미지·캐시 경로가 작동하도록 구성했습니다. 다운로드 링크는 인터넷 없이 실행할 PC용 HTML을 제공합니다. 소스를 바꾼 경우 `npm ci`, `npm run build` 후 변경된 `docs/`도 commit/push해야 합니다.

Pages는 정적 파일 호스팅입니다. **8인 방 서버를 실행하는 기능은 없습니다.** 원본 `public/`를 Pages에 올리면 멀티플레이 버튼만 보이고 서버가 없어 실패하므로, 이 패키지의 `docs/`를 사용하세요.

[GitHub Pages 소개](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages) · [브랜치와 폴더 게시 설정](https://docs.github.com/en/pages/getting-started-with-github-pages/configuring-a-publishing-source-for-your-github-pages-site)

## 3. 전체 온라인 서비스: Node 24 + 영구 디스크

Git 연결을 지원하는 Node 호스팅이나 본인의 서버에서 다음을 설정합니다.

| 항목 | 값 |
|---|---|
| Node | 24 이상 |
| 빌드 명령 | `npm ci && npm run build` |
| 시작 명령 | `npm start` |
| 포트 | `PORT` 환경변수, 기본 3000 |
| 공개 도메인 | `PUBLIC_ORIGIN=https://본인게임도메인` |
| 데이터 파일 | `DB_PATH=/영구디스크/trinity.sqlite` |
| 상태 점검 | `GET /healthz` |
| 프로세스 수 | 1개, 같은 SQLite 파일 사용 |

`PUBLIC_ORIGIN`은 경로가 없는 정확한 웹 주소입니다. HTTPS 프록시 뒤에서는 반드시 지정하세요. 모든 참가자는 이 서버의 웹 주소에 접속합니다. 루트 `/`에 게임, `/api/`에 방 서버를 함께 제공하므로 다른 출처로 CORS 연결을 설정할 필요가 없습니다. URL 하위 경로에 서버를 직접 설치하는 구성은 제공하지 않습니다.

영구 디스크를 반드시 연결하세요. 임시 파일시스템에서는 재배포 시 방 데이터가 사라집니다. 앱이 유휴 상태에서 자동 중지되는 호스팅은 게임 도중 연결이 끊길 수 있습니다. 실시간 대전 중에는 서버 프로세스가 계속 실행되어야 합니다. 여러 컨테이너로 자동 복제하는 구성은 이 SQLite 배포판의 범위에 포함되지 않습니다.

프록시가 클라이언트의 `X-Forwarded-For`를 검증·재작성하고 서버에 직접 접근할 수 없게 구성했다면 `TRUST_PROXY=1`을 사용할 수 있습니다. 그러면 마지막 프록시가 전달한 IP로 방 생성 제한을 구분합니다. 기본값은 요청 소켓의 IP를 사용합니다.

## 4. Docker로 실행

```sh
docker compose up -d --build
```

`http://localhost:3000`에서 확인합니다. `trinity-data` 볼륨에 DB가 저장됩니다. HTTPS 리버스 프록시와 연결할 경우 `compose.yaml`의 `environment`에 `PUBLIC_ORIGIN`을 추가하고 프록시가 3000번 포트로 전달하도록 설정합니다. 공개 서비스는 HTTPS로 운영하면 모바일 홈 화면 설치도 가능합니다.

```sh
docker compose logs -f
docker compose down
```

`down`은 컨테이너를 종료합니다. `down -v`는 DB 볼륨까지 지우므로 데이터 초기화를 원할 때만 사용하세요. Docker 실행 자체는 이번 환경에서 검증하지 않았으며 동일한 Node 서버의 직접 실행을 검증했습니다.

## 5. 운영과 업데이트

- 경기 시작 전 각 참가자가 동일한 게임 버전을 사용하도록 모든 탭을 닫고 다시 접속합니다.
- 서버 업데이트 전 종료를 안내하고, 진행 중인 경기가 끝난 뒤 재시작합니다.
- DB 백업은 서버를 정상 종료한 상태에서 `data/` 전체 또는 볼륨 전체를 복사하는 방식이 간단합니다. 실행 중에는 SQLite 백업 도구가 필요합니다.
- Node 서버의 마이그레이션은 파일 순서대로 적용되고 적용 이력이 기록됩니다. 기존 마이그레이션을 지우거나 이름을 변경하지 마세요.
- 브라우저의 PWA 캐시는 오프라인 AI용입니다. 네트워크를 끊으면 온라인 대전을 이어갈 수 없습니다.
- 경기 상태는 서버에 저장되지만 수동 세이브/로드 UI는 없습니다. 60초 연결 제한, 방 만료 규칙이 적용됩니다.

## 6. 실행이 안 될 때

| 현상 | 확인 |
|---|---|
| Node SQLite 오류 | `node --version`이 24 이상인지 확인 |
| 수정 내용이 안 보임 | `npm run build` 후 서버 재시작, 브라우저 탭 재실행 |
| 모바일 접속 불가 | 같은 Wi-Fi, PC 내부 IP, 방화벽 및 포트 확인 |
| 온라인 403 | `PUBLIC_ORIGIN`과 실제 접속 주소·HTTPS 일치 여부 확인 |
| Pages에서 빈 화면 | `main /docs` 선택 여부, 폴더 내용 전체 업로드 여부 확인 |
| 홈 화면 설치가 안 됨 | HTTPS 주소 및 브라우저 설치 메뉴 확인 |
| 방이 사라짐 | 대기실 30분·경기 3시간 만료, 영구 디스크 연결 확인 |

테스트 명령: `npm test`, 빌드 후 `npm run test:release`.
