CREATE TABLE `join_limits` (
	`bucket` text PRIMARY KEY NOT NULL,
	`failures` integer DEFAULT 0 NOT NULL,
	`expires_at` integer NOT NULL
);
--> statement-breakpoint
CREATE INDEX `join_limits_expiry_idx` ON `join_limits` (`expires_at`);--> statement-breakpoint
CREATE TABLE `rooms` (
	`code` text PRIMARY KEY NOT NULL,
	`pin_hash` text NOT NULL,
	`created_at` integer NOT NULL,
	`expires_at` integer NOT NULL,
	`host_hash` text NOT NULL,
	`slots` text NOT NULL,
	`mode` text DEFAULT 'ffa' NOT NULL,
	`difficulty` text DEFAULT 'normal' NOT NULL,
	`status` text DEFAULT 'waiting' NOT NULL,
	`revision` integer DEFAULT 0 NOT NULL,
	`game` text,
	`sim_at` integer NOT NULL,
	`creator_bucket` text NOT NULL,
	`reason` text
);
--> statement-breakpoint
CREATE UNIQUE INDEX `rooms_host_hash_unique` ON `rooms` (`host_hash`);--> statement-breakpoint
CREATE INDEX `rooms_expiry_idx` ON `rooms` (`expires_at`);--> statement-breakpoint
CREATE INDEX `rooms_creator_time_idx` ON `rooms` (`creator_bucket`,`created_at`);