# TRINITY FRONTIER

PC·모바일용 3종족 RTS. 이 패키지는 게임 전체 소스, 오프라인 PC판, GitHub Pages용 정적 웹앱, 최대 8인 서버, 표지와 한국어 게임 설명서를 포함합니다.

## 무엇을 실행할까요?

| 목적 | 사용할 파일 | 준비물 |
|---|---|---|
| PC에서 바로 AI 대전 | `public/downloads/TRINITY.html` | JavaScript를 지원하는 PC 브라우저 |
| 웹에서 AI 대전 · PWA 설치 | `docs/` 전체를 정적 호스팅 | GitHub Pages 등 |
| 1:1 · 최대 8인 · 팀당 최대 4인 · AI 혼합 | Node 서버로 `dist/` 실행 | Node 24 이상, 영구 저장공간 |
| 컨테이너로 온라인 서비스 | `Dockerfile`, `compose.yaml` | Docker 호스트, 영구 볼륨 |

PC 포터블판은 브라우저로 실행하는 단일 HTML입니다. 인터넷, npm 설치, 별도 서버가 필요 없습니다. 네이티브 EXE/APK는 아닙니다. 오프라인판과 Pages판은 AI 대전만 지원합니다. 온라인은 아래 Node 서버가 웹 화면과 API를 함께 제공합니다. 외부 게임 서버 주소나 비밀키가 들어 있지 않습니다. AI는 게임 내부 로직으로 동작하며 AI API 키가 필요 없습니다.

## 빠른 서버 실행

압축을 풀고 이 README와 `package.json`이 있는 폴더에서 실행하세요. **Node 24 이상**이 필요합니다.

```sh
node --version
npm start
```

배포용 `dist/`를 미리 포함했으므로 원본 파일을 그대로 실행할 때는 `npm ci` 없이 시작할 수 있습니다. PC에서 `http://localhost:3000`에 접속합니다. 같은 공유기에 연결된 모바일은 PC의 내부 IP 주소와 3000번 포트로 접속합니다. 예: `http://192.168.0.10:3000`. 방화벽에서 허용된 네트워크여야 합니다. 로컬 IP의 HTTP에서도 게임은 가능하지만 PWA 설치는 HTTPS가 필요합니다.

소스를 수정한 뒤에는 다음 순서로 다시 빌드합니다.

```sh
npm ci
npm test
npm run build
npm run test:release
npm start
```

`npm ci`에는 의존성 다운로드를 위한 인터넷이 필요합니다. 실행 중 서버를 종료하려면 Ctrl+C를 누릅니다. 현재 경로의 `data/trinity.sqlite`에 방 데이터가 저장됩니다. 서버 정지 중에도 방 만료 및 연결 제한 시간은 흐릅니다.

## Git 업로드 및 웹 서비스

상세한 복사 가능한 명령과 배포 설정은 [DEPLOY.md](DEPLOY.md)를 보세요. Git에 올리는 것과 온라인 서버를 운영하는 것은 별도 단계입니다.

- **GitHub Pages**: `main` 브랜치의 `/docs`를 게시하면 PC·모바일 AI 웹 게임을 서비스합니다. 이미 빌드한 파일을 포함했습니다.
- **온라인 멀티플레이**: 저장소를 Node 또는 Docker 호스팅에 연결하고 같은 도메인에서 웹과 서버를 서비스하세요. 시작 명령 `npm start`, 포트 `3000`, 영구 경로 `data/`, 공개 HTTPS 주소는 `PUBLIC_ORIGIN`으로 지정합니다.
- GitHub Pages는 정적 호스팅이므로 이 게임의 방 서버를 실행하지 않습니다. 온라인 서비스에는 서버 실행 환경이 필요합니다. [GitHub 공식 안내](https://docs.github.com/en/pages/getting-started-with-github-pages/what-is-github-pages)

## 게임 내용

철혈 연방, 군락 연맹, 성휘 의회가 순환 상성을 이루며 자원을 채집하고 병력을 생산해 상대 사령부를 파괴합니다. 16개 맵, 종족별 일꾼 포함 21개 유닛 이름, 전투·지원 18종 상세 일러스트, I~III 발전 단계와 공통·종족별 연구가 있습니다.

AI 교전은 플레이어 한 명과 AI 둘의 개인전입니다. 온라인 대기실은 8자리 영문·숫자 방 코드와 6자리 숫자 입장번호를 사용합니다. 개인전 또는 팀전에서 인간과 AI를 합해 최대 8명, 한 팀 최대 4명으로 설정합니다.

자세한 조작·상성·유닛·테크트리·연구·맵 설명은 `TRINITY-Game-Guide-KO.pdf`와 `GAME-GUIDE.md`에 있습니다. 모든 성장 요소는 경기마다 초기화됩니다. 경기 수동 저장, 캠페인, 영구 계정 성장은 없습니다.

## 소스 구성

| 경로 | 역할 |
|---|---|
| `public/engine.js` | 경제, 전투, 길찾기, AI, 동맹, 승패 |
| `public/maps.js`, `catalog.js` | 맵, 유닛 개성, 상성, 연구 정의 |
| `public/main.js`, `renderer.js`, `expansion-ui.js` | PC·터치 UI, Canvas 전장, 도감 |
| `public/network.js`, `runtime.js` | 서버 연결 및 실행 모드 |
| `public/install.js`, `sw.js`, `manifest.webmanifest` | PWA 설치 및 오프라인 캐시 |
| `server/rooms.js` | 서버 판정, 방 권한, 시야, 명령 중복 방지 |
| `server/node.mjs`, `sqlite.mjs`, `worker.js` | Node HTTP 서버, SQLite 어댑터, 정적 파일 |
| `drizzle/`, `db/` | 데이터베이스 정의 및 순차 마이그레이션 |
| `scripts/build.mjs` | 포터블 HTML, Pages `docs/`, 서버 `dist/` 생성 |
| `tests/` | 게임 규칙, 8인 API, 배포판 검증 |

Node 서버는 첫 실행 시 제공된 SQL 마이그레이션을 한 번씩 적용합니다. `dist/`는 Git 추적 제외 대상이지만 이번 다운로드에는 즉시 실행용으로 포함했습니다. Git 호스팅 빌드 과정에서 `npm ci`와 `npm run build`로 다시 생성하세요. `docs/`는 Pages 게시용으로 Git에 포함합니다.

## 검증과 버전

v4.1.0 / 2026-09-15. 61개 기본 규칙 검사, 21개 게임·멀티플레이 시나리오, 3개 배포판 시나리오 통과. Node HTTP에서 8명 참가·4대4·명령 처리·재시작 복구, 포터블 파일 구문, 정적 호스팅 하위 경로 및 캐시 경로를 확인했습니다. 실제 Windows 실행, 모바일 기기 조작, 실제 8대 기기 인터넷 대전과 Docker 이미지 실행은 이 환경에서 검증하지 않았습니다.

게임 이름과 그래픽은 독자 제작했습니다. 표지는 홍보용 콘셉트 일러스트이며 실제 플레이 화면은 2D 등각 전장입니다. 아트 생성 정보는 `ART-NOTES.md`에 있습니다.
