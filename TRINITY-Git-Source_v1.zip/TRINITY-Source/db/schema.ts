import {sqliteTable,text,integer,index} from 'drizzle-orm/sqlite-core';
export const rooms=sqliteTable('rooms',{
 code:text('code').primaryKey(),pinHash:text('pin_hash').notNull(),createdAt:integer('created_at').notNull(),expiresAt:integer('expires_at').notNull(),
 hostHash:text('host_hash').notNull().unique(),slots:text('slots').notNull(),mapId:text('map_id').notNull().default('basin'),mode:text('mode').notNull().default('ffa'),difficulty:text('difficulty').notNull().default('normal'),
 status:text('status').notNull().default('waiting'),revision:integer('revision').notNull().default(0),
 game:text('game'),simAt:integer('sim_at').notNull(),creatorBucket:text('creator_bucket').notNull(),reason:text('reason')
},table=>[index('rooms_expiry_idx').on(table.expiresAt),index('rooms_creator_time_idx').on(table.creatorBucket,table.createdAt)]);
export const joinLimits=sqliteTable('join_limits',{bucket:text('bucket').primaryKey(),failures:integer('failures').notNull().default(0),expiresAt:integer('expires_at').notNull()},table=>[index('join_limits_expiry_idx').on(table.expiresAt)]);
