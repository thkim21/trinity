import test from 'node:test';
import assert from 'node:assert/strict';
import {DatabaseSync} from 'node:sqlite';
import {readFileSync,readdirSync} from 'node:fs';
import {randomBytes} from 'node:crypto';
import {Game} from '../public/engine.js';
import {handleApi,applyCommand,perspective,visibleTo,PROTOCOL,DISCONNECT_MS} from '../server/rooms.js';

// Exercise the actual HTTP handlers and generated migration against real SQLite.
// Async statement boundaries also exercise the room revision compare-and-swap.
class D1 {
 constructor(){this.sql=new DatabaseSync(':memory:');for(const file of readdirSync('drizzle').filter(f=>f.endsWith('.sql')).sort())this.sql.exec(readFileSync('drizzle/'+file,'utf8'));}
 withSession(){return this;}
 prepare(sql){const db=this.sql;const statement={params:[],bind(...params){this.params=params;return this;},async first(){return db.prepare(sql).get(...this.params)||null;},async all(){return {results:db.prepare(sql).all(...this.params)};},async run(){const r=db.prepare(sql).run(...this.params);return {success:true,meta:{changes:Number(r.changes)}};}};return statement;}
 async batch(statements){this.sql.exec('BEGIN');try{const results=[];for(const statement of statements)results.push(await statement.run());this.sql.exec('COMMIT');return results;}catch(error){this.sql.exec('ROLLBACK');throw error;}}
}
function fixture(){
 const DB=new D1();let now=100000000;const pin='028491';
 const tokens=Array.from({length:10},()=>randomBytes(32).toString('hex'));
 const api=async(path,body={},seat=0,headers={})=>{const response=await handleApi(new Request('https://game.test'+path,{method:'POST',headers:{'Content-Type':'application/json',Origin:'https://game.test',Authorization:'Bearer '+tokens[seat],'CF-Connecting-IP':'192.0.2.'+(seat+1),...headers},body:JSON.stringify({protocol:PROTOCOL,...body})}),{DB},{now:()=>now});return {status:response.status,data:await response.json()};};
 const create=async()=>{const result=await api('/api/rooms',{token:tokens[0],faction:0,pin});assert.equal(result.status,201);return result.data.code;};
 const call=(code,operation,body={},seat=0,headers={})=>api('/api/rooms/'+code+'/'+operation,body,seat,headers);
 const join=(code,seat,entryPin=pin)=>call(code,'join',{token:tokens[seat],faction:seat%3,pin:entryPin},seat);
 const load=code=>Game.hydrate(JSON.parse(DB.sql.prepare('SELECT game FROM rooms WHERE code=?').get(code).game));
 const persist=(code,game)=>DB.sql.prepare('UPDATE rooms SET game=? WHERE code=?').run(JSON.stringify(game.serialize()),code);
 return {DB,tokens,pin,api,create,call,join,load,persist,advance:ms=>now+=ms};
}
async function addAI(f,code,seat,alliance){assert.equal((await f.call(code,'config',{slot:seat,kind:'ai',...(alliance===undefined?{}:{alliance})})).status,200);}

test('8-character rooms require a separate 6-digit PIN; secrets are never returned',async()=>{
 const f=fixture(),code=await f.create();assert.match(code,/^[A-HJ-NP-Z2-9]{8}$/);
 const row=f.DB.sql.prepare('SELECT * FROM rooms').get();assert.notEqual(row.pin_hash,f.pin);assert.equal(row.pin_hash.length,64);assert(!JSON.stringify(row).includes(f.tokens[0]));
 const wrong=await f.join(code,1,'111111');assert.equal(wrong.status,403);
 assert.equal((await f.join(code,1,'12345')).status,400);
 const correct=await f.join(code,1);assert.equal(correct.status,200);assert.equal(correct.data.me,1);
 assert(!JSON.stringify(correct.data).includes('tokenHash'));assert(!JSON.stringify(correct.data).includes('pin_hash'));
 assert.equal((await f.api('/api/rooms',{token:f.tokens[0],faction:0,pin:f.pin})).data.code,code,'create retries are idempotent');
 assert.equal((await f.call(code,'sync',{},8)).status,403);
 assert.equal((await f.call(code,'sync',{},0,{Origin:'https://unrelated.test'})).status,403);
 assert.equal((await f.call(code,'sync',{},0,{Origin:'null'})).status,200,'downloaded game can authenticate');
 assert.equal((await f.call(code,'sync',{protocol:2})).status,409);
});

test('wrong PIN attempts are limited without locking a different participant out',async()=>{
 const f=fixture(),code=await f.create();for(let i=0;i<10;i++)assert.equal((await f.join(code,1,'000000')).status,403);
 assert.equal((await f.join(code,1)).status,429);assert.equal((await f.join(code,2)).status,200);
 f.advance(120001);assert.equal((await f.join(code,1)).status,200);
});

test('8 simultaneous entrants fill unique seats, the ninth is rejected, and only host starts',async()=>{
 const f=fixture(),code=await f.create();const joins=await Promise.all(Array.from({length:7},(_,i)=>f.join(code,i+1)));
 for(let i=0;i<joins.length;i++){if(joins[i].status===503)joins[i]=await f.join(code,i+1);assert.equal(joins[i].status,200);}
 assert.equal(new Set(joins.map(r=>r.data.me)).size,7);
 assert.equal((await f.join(code,8)).status,409);
 assert.equal((await f.call(code,'start',{},1)).status,403);
 assert.equal((await f.call(code,'config',{mode:'teams'},1)).status,403);
 assert.equal((await f.call(code,'start')).status,409,'readiness is mandatory');
 for(let i=1;i<8;i++)assert.equal((await f.call(code,'ready',{ready:true},i)).status,200);
 const start=await f.call(code,'start');assert.equal(start.status,200);assert.equal(start.data.status,'playing');
 assert.equal(start.data.game.teams.length,8);assert.equal(new Set(start.data.game.teams.map(t=>t.alliance)).size,8);
 const game=f.load(code);for(const team of game.teams){assert.equal(game.own(team.id).length,12);assert.equal(team.kind,'human');}
 const snapshots=await Promise.all(Array.from({length:8},(_,i)=>f.call(code,'sync',{},i)));
 for(const r of snapshots)assert([200,503].includes(r.status));
 for(let i=0;i<8;i++){const sync=await f.call(code,'sync',{},i);assert.equal(sync.status,200);assert.equal(sync.data.game.teams[0].seat,i===0?0:joins[i-1].data.me);assert(sync.data.game.entities.every(e=>e.team===0),'initial enemy entities hidden');}
 assert.equal((await f.join(code,8)).status,409,'late entry is disallowed');
});

test('teams allow at most four members and support mixed humans, AI and closed slots',async()=>{
 const f=fixture(),code=await f.create();assert.equal((await f.join(code,1)).status,200);
 assert.equal((await f.call(code,'config',{mode:'teams',difficulty:'hard'})).status,200);
 for(let seat=2;seat<8;seat++)await addAI(f,code,seat);
 assert.equal((await f.call(code,'config',{slot:1,alliance:0})).status,400,'five members cannot be assigned');
 assert.equal((await f.call(code,'config',{slot:2,kind:'closed'})).status,200);
 assert.equal((await f.call(code,'config',{slot:1,alliance:0})).status,200);
 assert.equal((await f.call(code,'config',{slot:1,kind:'ai'})).status,400,'occupied humans cannot be overwritten');
 assert.equal((await f.call(code,'ready',{ready:true},1)).status,200);
 assert.equal((await f.call(code,'config',{slot:7,faction:2})).status,200);
 assert.equal((await f.call(code,'start')).status,409,'changing settings resets readiness');
 await f.call(code,'ready',{ready:true},1);const started=await f.call(code,'start');assert.equal(started.status,200);
 assert.equal(started.data.game.teams.length,7);assert.equal(started.data.game.teams.filter(t=>t.kind==='ai').length,5);assert.equal(started.data.game.difficulty,'hard');
 const second=await f.call(code,'sync',{},1);assert.equal(second.data.game.teams[0].seat,1);assert.equal(second.data.game.teams[0].alliance,0);
});

test('host plus AI can start; a lone participant or only one alliance cannot',async()=>{
 const f=fixture(),code=await f.create();assert.equal((await f.call(code,'start')).status,409);
 await addAI(f,code,1,0);await f.call(code,'config',{mode:'teams'});assert.equal((await f.call(code,'start')).status,409);
 await f.call(code,'config',{slot:1,alliance:1});assert.equal((await f.call(code,'start')).status,200);
 const before=f.load(code);for(let i=0;i<16;i++){f.advance(1000);assert.equal((await f.call(code,'sync')).status,200);}
 const after=f.load(code);assert(after.time>=15.9);assert(after.teamStats[0].gathered>before.teamStats[0].gathered);assert(after.teamStats[1].trained>0,'AI produces units through the server simulation');assert(after.teams[0].alive&&after.teams[1].alive);
});

test('concurrent commands persist independently; duplicate retries spend resources only once',async()=>{
 const f=fixture(),code=await f.create();await f.join(code,1);await f.call(code,'ready',{ready:true},1);await f.call(code,'start');
 const before=f.load(code),hq=before.own(0).find(e=>e.type==='hq'),other=before.own(1).find(e=>e.type==='hq');
 const command={seq:1,action:'train',id:hq.id,unit:'worker'},guestCommand={seq:1,action:'train',id:other.id,unit:'worker'};
 const responses=await Promise.all([f.call(code,'sync',{commands:[command]}),f.call(code,'sync',{commands:[guestCommand]},1),f.call(code,'sync',{commands:[command]})]);
 assert(responses.every(r=>r.status===200));const after=f.load(code);assert.equal(after.entity(hq.id).queue.length,1);assert.equal(after.entity(other.id).queue.length,1);
 assert.equal(before.teams[0].ore-after.teams[0].ore,before.cost('worker',0).ore);
 const invalid=await f.call(code,'sync',{commands:[{seq:2,action:'train',id:other.id,unit:'worker'}]});assert.equal(invalid.data.ack,2);assert.equal(invalid.data.errors.length,1);assert.equal(f.load(code).entity(other.id).queue.length,1);
 const gap=await f.call(code,'sync',{commands:[{seq:4,action:'train',id:hq.id,unit:'worker'}]});assert.equal(gap.data.ack,2,'missing commands are not silently skipped');
 const resume=await f.call(code,'sync');assert.equal(resume.data.ack,2);
 await f.call(code,'sync',{commands:[{seq:3,action:'train',id:hq.id,unit:'worker'}]});assert.equal(f.load(code).entity(hq.id).queue.length,2);
});

test('shared vision reveals allies and nearby enemies, without allowing allied unit control or damage',()=>{
 const game=new Game({mode:'teams',players:[{seat:0,kind:'human',faction:0,alliance:0},{seat:2,kind:'ai',faction:1,alliance:0},{seat:7,kind:'human',faction:2,alliance:1}]});
 const own=game.own(0).find(e=>e.type==='pike'),ally=game.own(1).find(e=>e.type==='pike'),enemy=game.own(2).find(e=>e.type==='pike');enemy.x=ally.x+30;enemy.y=ally.y;
 assert(visibleTo(game,0,enemy));const view=perspective(game,0);assert(view.entities.some(e=>e.id===enemy.id));assert(view.entities.some(e=>e.id===ally.id));assert.equal(view.teams[1].ore,0);assert.equal(view.teams[2].ore,0);
 assert.equal(applyCommand(game,0,{action:'order',ids:[ally.id],order:'move',target:{x:500,y:500}}).ok,false);
 assert.equal(applyCommand(game,0,{action:'order',ids:[own.id],order:'attack',target:{id:ally.id}}).ok,false);
 const hp=ally.hp;own.x=ally.x;own.y=ally.y;game.attack(own,ally,.05);assert.equal(ally.hp,hp);
 game.forfeit(0);assert.equal(game.result,null);assert.equal(perspective(game,0).result,null,'eliminated player may watch surviving ally');
 game.forfeit(2);assert.equal(game.winnerAlliance,0);assert.equal(perspective(game,0).result,'victory');assert.equal(perspective(game,2).result,'defeat');
});

test('FFA elimination does not stop other participants; one surviving player wins',()=>{
 const game=new Game({players:Array.from({length:8},(_,i)=>({seat:i,kind:'human',faction:i%3,alliance:i}))});
 game.forfeit(0);assert.equal(game.result,null);assert.equal(perspective(game,0).result,'defeat');assert.equal(perspective(game,1).result,null);
 for(let i=1;i<7;i++)game.forfeit(i);assert.equal(game.winner,7);assert.equal(perspective(game,7).result,'victory');
});

test('disconnect grace is 60 seconds; a connected teammate survives a player leaving',async()=>{
 const f=fixture(),code=await f.create();await f.join(code,1);await f.call(code,'config',{mode:'teams',slot:1,alliance:0});await addAI(f,code,2,1);await f.call(code,'ready',{ready:true},1);await f.call(code,'start');
 f.advance(DISCONNECT_MS-1);const before=await f.call(code,'sync');assert.equal(before.data.players[1].alive,true);
 f.advance(2);const after=await f.call(code,'sync');assert.equal(after.data.players[1].alive,false);assert.equal(after.data.players[0].alive,true);assert.equal(after.data.status,'playing');
 const late=await f.call(code,'sync',{},1);assert.equal(late.data.game.result,null);assert.equal(late.data.game.teams[0].alive,false);
 const left=await f.call(code,'leave');assert.equal(left.data.status,'finished');assert.equal(left.data.game.result,'defeat');
});

test('waiting participants can leave and rejoin; a host closes the lobby; codes expire',async()=>{
 const f=fixture(),code=await f.create();await f.join(code,1);await f.call(code,'leave',{},1);assert.equal((await f.join(code,2)).data.me,1);
 await f.call(code,'leave');assert.equal((await f.call(code,'sync',{},2)).status,410);
 f.tokens[0]=randomBytes(32).toString('hex'); // Each new room receives a new client ticket.
 const next=await f.create();f.advance(30*60000+1);assert.equal((await f.join(next,3)).status,404);
});

test('8-player simulation round-trips deterministically and handles an expanded army',()=>{
 const game=new Game({players:Array.from({length:8},(_,i)=>({seat:i,kind:i?'ai':'human',faction:i%3,alliance:i%2})),mode:'teams'});
 for(const team of game.teams)for(let i=0;i<22;i++)game.addUnit(team.id,i%2?'pike':'ranger',team.base.x+20+(i%6)*15,team.base.y+150+Math.floor(i/6)*20);
 const copy=Game.hydrate(game.serialize());for(let i=0;i<20;i++){game.update(.05);copy.update(.05);}
 assert.deepEqual(copy.serialize(),game.serialize());assert.equal(copy.teams.length,8);assert(copy.entities.every(e=>Number.isFinite(e.x)&&Number.isFinite(e.y)));assert(!JSON.stringify(copy.serialize()).includes('navCache'));
});

test('host-selected map survives sync and start; guests cannot change it or bypass readiness',async()=>{
 const f=fixture(),code=await f.create();await f.join(code,1);await f.call(code,'ready',{ready:true},1);
 assert.equal((await f.call(code,'config',{mapId:'gold-rush'},1)).status,403);
 assert.equal((await f.call(code,'config',{mapId:'missing-map'})).status,400);
 const changed=await f.call(code,'config',{mapId:'citadel'});assert.equal(changed.status,200);assert.equal(changed.data.mapId,'citadel');assert.equal(changed.data.players[1].ready,false);
 const guest=await f.call(code,'sync',{},1);assert.equal(guest.data.mapId,'citadel');assert.equal((await f.call(code,'start')).status,409);
 await f.call(code,'ready',{ready:true},1);const started=await f.call(code,'start');assert.equal(started.data.game.mapId,'citadel');assert(started.data.game.highgrounds.length>0);assert.equal(f.load(code).mapId,'citadel');
 assert.equal((await f.call(code,'config',{mapId:'basin'})).status,403);
 const game=f.load(code);game.teams[0].ore=1000;game.teams[0].crystal=1000;game.addBuilding(0,'academy',720,1500,true);f.persist(code,game);
 const research=await f.call(code,'sync',{commands:[{seq:1,action:'research',id:'logistics'}]});assert.equal(research.data.ack,1);assert.equal(f.load(code).teams[0].research.id,'logistics');
 const cancel=await f.call(code,'sync',{commands:[{seq:2,action:'cancelResearch',kind:'research'}]});assert.equal(cancel.data.ack,2);assert.equal(f.load(code).teams[0].research,null);
});
