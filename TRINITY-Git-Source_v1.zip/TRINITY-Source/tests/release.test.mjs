import test from 'node:test';
import assert from 'node:assert/strict';
import {spawn} from 'node:child_process';
import {mkdtemp,readFile,rm} from 'node:fs/promises';
import {tmpdir} from 'node:os';
import {join} from 'node:path';
import {randomBytes} from 'node:crypto';
import {once} from 'node:events';
import vm from 'node:vm';
import {SQLiteDB} from '../server/sqlite.mjs';

async function start(path,extra={}){
 const child=spawn(process.execPath,['dist/server/node.mjs'],{env:{...process.env,PORT:'0',HOST:'127.0.0.1',DB_PATH:path,...extra},stdio:['ignore','pipe','pipe']});
 let output='',errors='';child.stderr.on('data',b=>errors+=b);
 const port=await new Promise((resolve,reject)=>{const timer=setTimeout(()=>{child.kill();reject(new Error('Server startup timed out: '+errors));},10000);child.stdout.on('data',b=>{output+=b;const match=output.match(/ready on port (\d+)/);if(match){clearTimeout(timer);resolve(match[1]);}});child.once('exit',code=>{clearTimeout(timer);reject(new Error('Server exited '+code+': '+errors));});});
 return {url:'http://127.0.0.1:'+port,async stop(){const done=once(child,'exit');child.kill('SIGTERM');await done;},errors:()=>errors};
}
test('portable HTML is self contained, offline enforced, and static paths work below a repository path',async()=>{
 const html=await readFile('public/downloads/TRINITY.html','utf8');
 assert(html.includes('connect-src \'none\''));assert(html.includes('globalThis.TRINITY_MODE="offline"'));assert(html.includes('data:image/webp;base64,'));
 assert(!/<script[^>]+src=/i.test(html));assert(!/@import\s+url/.test(html));assert(!html.includes('chatgpt.site'));
 const script=html.match(/<script>([\s\S]*?)<\/script>/)[1];new vm.Script(script);
 const pages=await readFile('docs/index.html','utf8');assert(pages.includes('TRINITY_MODE="static"'));assert(!/(?:href|src)="\//.test(pages));
 const manifest=JSON.parse(await readFile('docs/manifest.webmanifest','utf8'));assert.equal(new URL(manifest.start_url,'https://example.test/repo/manifest.webmanifest').pathname,'/repo/');
 const handlers={},cached=[];const context={self:{location:{href:'https://example.test/repo/sw.js'},addEventListener(name,fn){handlers[name]=fn;}},URL,Request,caches:{open:async()=>({addAll:async values=>cached.push(...values.map(r=>r.url))})}};
 vm.runInNewContext(await readFile('docs/sw.js','utf8'),context);await new Promise((resolve,reject)=>handlers.install({waitUntil(promise){promise.then(resolve,reject);}}));
 assert(cached.every(url=>url.startsWith('https://example.test/repo/')));assert(cached.includes('https://example.test/repo/runtime.js'));
 for(const url of cached)await readFile('docs/'+(new URL(url).pathname.replace('/repo/','')||'index.html'));
});
test('Node adapter: eight players, 4v4, commands, PIN checks, restart persistence and HTTP limits',async()=>{
 const folder=await mkdtemp(join(tmpdir(),'trinity-release-'));const db=join(folder,'game.sqlite');let server=await start(db);
 const tokens=Array.from({length:9},()=>randomBytes(32).toString('hex')),pin='074183';
 const api=async(path,body={},seat=0)=>{for(let attempt=0;attempt<4;attempt++){const r=await fetch(server.url+path,{method:'POST',headers:{'Content-Type':'application/json',Origin:server.url,Authorization:'Bearer '+tokens[seat]},body:JSON.stringify({protocol:4,...body})});const data=await r.json();if(r.status===503&&attempt<3)continue;return {status:r.status,data};}};
 try{
  assert.equal((await fetch(server.url+'/')).status,200);assert.match((await fetch(server.url+'/art/units.webp')).headers.get('content-type'),/image\/webp/);
  const room=await api('/api/rooms',{token:tokens[0],faction:0,pin,mapId:'citadel'});assert.equal(room.status,201);const code=room.data.code;assert.match(code,/^[A-HJ-NP-Z2-9]{8}$/);
  const call=(op,body={},seat=0)=>api('/api/rooms/'+code+'/'+op,body,seat);
  assert.equal((await call('join',{token:tokens[1],faction:1,pin:'000000'},1)).status,403);
  const joined=await Promise.all(Array.from({length:7},(_,i)=>call('join',{token:tokens[i+1],faction:(i+1)%3,pin},i+1)));
  assert(joined.every(r=>r.status===200));assert.equal(new Set(joined.map(r=>r.data.me)).size,7);
  assert.equal((await call('join',{token:tokens[8],faction:2,pin},8)).status,409);
  assert.equal((await call('config',{mode:'teams'})).status,200);
  assert.equal((await call('start')).status,409);
  for(let i=1;i<8;i++)assert.equal((await call('ready',{ready:true},i)).status,200);
  const started=await call('start');assert.equal(started.status,200);assert.equal(started.data.game.teams.length,8);assert.equal(started.data.mapId,'citadel');
  const own=started.data.game.entities.find(e=>e.kind==='unit');
  assert.equal((await call('sync',{commands:[{seq:1,action:'order',ids:[own.id],order:'stop'}]})).data.ack,1);
  await server.stop();server=await start(db);
  const resumed=await call('sync',{commands:[]});assert.equal(resumed.status,200);assert.equal(resumed.data.status,'playing');assert.equal(resumed.data.ack,1);
  const foreign=await fetch(server.url+'/api/rooms/'+code+'/sync',{method:'POST',headers:{Origin:'https://unrelated.test','Content-Type':'application/json'},body:'{"protocol":4}'});assert.equal(foreign.status,403);
  assert.equal((await fetch(server.url+'/api/rooms',{method:'POST',body:'x'.repeat(25000)})).status,413);
  assert.equal((await fetch(server.url+'/healthz')).status,200);assert(!server.errors().includes('Request failed'));
 }finally{await server.stop();await rm(folder,{recursive:true,force:true});}
});
test('SQLite batches are atomic under concurrent creation and roll back on failure',async()=>{
 const DB=new SQLiteDB(':memory:',new URL('../drizzle/',import.meta.url));try{
  DB.sql.exec('CREATE TABLE atomic_test (id INTEGER PRIMARY KEY)');
  await Promise.all(Array.from({length:8},(_,i)=>DB.batch([DB.prepare('INSERT INTO atomic_test VALUES (?)').bind(i*2),DB.prepare('INSERT INTO atomic_test VALUES (?)').bind(i*2+1)])));
  assert.equal(DB.sql.prepare('SELECT count(*) AS n FROM atomic_test').get().n,16);
  await assert.rejects(DB.batch([DB.prepare('INSERT INTO atomic_test VALUES (20)'),DB.prepare('INSERT INTO atomic_test VALUES (0)')]));
  assert.equal(DB.sql.prepare('SELECT count(*) AS n FROM atomic_test').get().n,16);
 }finally{DB.close();}
});
