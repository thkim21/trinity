import test from 'node:test';
import assert from 'node:assert/strict';
import {Game,UNITS,BUILDINGS} from '../public/engine.js';
import {MAPS,getMap} from '../public/maps.js';
import {PROFILES,RESEARCH} from '../public/catalog.js';
import {applyCommand,perspective} from '../server/rooms.js';

const advance=(g,seconds)=>{for(let i=0;i<seconds*20&&!g.result;i++)g.update(.05);};
function quiet(faction=0){const g=new Game({players:[{seat:0,kind:'human',faction,alliance:0},{seat:1,kind:'human',faction:(faction+1)%3,alliance:1}]});g.teams[0].ore=20000;g.teams[0].crystal=20000;return g;}
function addLab(g,type){const b=g.addBuilding(0,type,620+Object.keys(BUILDINGS).indexOf(type)*70,1700,true);return b;}
function readyTech(g,tier=2){addLab(g,'academy');addLab(g,'foundry');addLab(g,'relay');g.teams[0].tier=tier;g.refreshVitals(0);}

test('16 authored layouts have unique geometry; every starting army and expansion is reachable',()=>{
 assert.equal(MAPS.length,16);assert.equal(new Set(MAPS.map(m=>m.id)).size,16);assert.equal(new Set(MAPS.map(m=>JSON.stringify(m.obstacles))).size,16);
 for(const map of MAPS)for(const count of [2,3,4,8]){
  const game=new Game({mapId:map.id,players:Array.from({length:count},(_,i)=>({seat:i,kind:'human',faction:i%3,alliance:i}))});
  assert.deepEqual(game.obstacles,map.obstacles);assert.equal(game.mapId,map.id);
  const unit=game.own().find(e=>e.type==='pike'),grid=game.navGrid(unit),{cols,rows,blocked}=grid;
  const cell=p=>Math.floor(p.y/40)*cols+Math.floor(p.x/40);
  const seen=new Set([cell(unit)]),queue=[cell(unit)];for(let q=0;q<queue.length;q++){const index=queue[q],x=index%cols,y=Math.floor(index/cols);for(const [dx,dy] of [[1,0],[-1,0],[0,1],[0,-1]]){const nx=x+dx,ny=y+dy,id=ny*cols+nx;if(nx>=0&&ny>=0&&nx<cols&&ny<rows&&!blocked[id]&&!seen.has(id)){seen.add(id);queue.push(id);}}}
  const reachable=(point,radius=70)=>[...seen].some(index=>Math.hypot((index%cols)*40+20-point.x,Math.floor(index/cols)*40+20-point.y)<=radius);
  for(const team of game.teams){const military=game.own(team.id).filter(e=>e.type==='pike');assert(military.some(e=>reachable(e)),map.id+' '+count+' spawn '+team.id+' is isolated');const worker=game.own(team.id).find(e=>e.type==='worker');assert(reachable(worker),map.id+' '+count+' player '+team.id+' worker cannot leave base at '+worker.x+','+worker.y);}
  for(const resource of game.resources){assert(resource.x>0&&resource.x<2400&&resource.y>0&&resource.y<2000,map.id+' out-of-map resource');assert(!map.obstacles.some(o=>((resource.x-o.x)/o.rx)**2+((resource.y-o.y)/o.ry)**2<1),map.id+' resource inside obstruction');assert(reachable(resource,65),map.id+' unreachable resource at '+resource.x+','+resource.y);}
 }
});

test('3-stage tree enforces buildings, costs and unlocks; existing and newly trained stats agree',()=>{
 const g=quiet(2),t=g.teams[0],b=g.own().find(e=>e.type==='barracks');assert(!g.upgrade().ok);addLab(g,'academy');assert(g.upgrade().ok);assert(!g.upgrade().ok);advance(g,36);assert.equal(t.tier,2);assert(g.train(b.id,'siege').ok);assert(!g.upgrade().ok,'both advanced buildings are required');
 addLab(g,'foundry');assert(!g.upgrade().ok);addLab(g,'relay');assert(g.upgrade().ok);advance(g,56);assert.equal(t.tier,3);assert(!g.upgrade().ok,'no stage IV');
 const foundry=g.own().find(e=>e.type==='foundry');assert(g.train(foundry.id,'titan').ok);advance(g,34);assert(g.own().some(e=>e.type==='titan'));
 const old=g.own().find(e=>e.type==='pike'),fresh=g.addUnit(0,'pike',600,1700);assert.equal(old.maxHp,fresh.maxHp);assert.equal(old.maxShield,fresh.maxShield);
});

test('research requirements, level caps, resource charging and partial refunds are authoritative',()=>{
 const g=quiet(),t=g.teams[0];assert(!g.research('weapons').ok);readyTech(g);const before=t.ore;assert(g.research('weapons').ok);assert.equal(before-t.ore,RESEARCH.weapons.ore);assert(!g.research('armor').ok);advance(g,26);assert.equal(g.tech(0,'weapons'),1);
 assert(g.research('weapons').ok);advance(g,26);assert.equal(g.tech(0,'weapons'),2);assert(!g.research('weapons').ok,'third level needs III');
 t.tier=3;assert(g.research('weapons').ok);advance(g,26);assert.equal(g.tech(0,'weapons'),3);assert(!g.research('weapons').ok);
 assert(!g.research('frenzy').ok,'another faction cannot research this ability');assert(g.research('armor').ok);advance(g,5);const work={...t.research},balance=t.ore;t.kind='human';assert(g.cancelResearch().ok);assert.equal(t.ore-balance,Math.floor(work.cost.ore*work.remaining/work.total));assert.equal(g.tech(0,'armor'),0);assert(!g.cancelResearch().ok);
 assert(g.research('logistics').ok);assert(!g.upgrade().ok);const lab=g.own().find(e=>e.type==='academy');g.destroy(lab,1);advance(g,.1);assert.equal(t.research,null);assert.equal(g.tech(0,'logistics'),0,'destroyed lab cannot complete research');
});

test('completed weapons, armor, range, mobility and logistics change real statistics',()=>{
 const g=quiet(),u=g.own().find(e=>e.type==='ranger'),worker=g.own().find(e=>e.type==='worker');readyTech(g);const power=g.power(u),armor=g.armor(u),range=g.range(u),speed=g.speed(worker);
 for(const id of ['weapons','armor','optics','mobility','logistics']){assert(g.research(id).ok);advance(g,RESEARCH[id].time+1);}
 assert.equal(g.power(u),power*1.12);assert.equal(g.armor(u),armor+2);assert.equal(g.range(u),range*1.15);assert.equal(g.speed(worker),speed*1.12);
 const a=quiet(),b=quiet();b.teams[0].tech.logistics=2;advance(a,35);advance(b,35);assert(b.teamStats[0].gathered>a.teamStats[0].gathered,'logistics raises delivered income');
});

test('faction research modifies armor, attack cadence and all existing shields',()=>{
 for(let faction=0;faction<3;faction++){
  const g=quiet(faction);readyTech(g,3);const id=['aegis','frenzy','resonance'][faction],u=g.own().find(e=>e.type==='pike'),baseArmor=g.armor(u),baseShield=u.maxShield;assert(g.research(id).ok);advance(g,41);assert.equal(g.tech(0,id),1);
  if(faction===0)assert.equal(g.armor(u),baseArmor+3);
  if(faction===1){const enemy=g.addUnit(1,'pike',u.x+20,u.y);u.cooldown=0;g.attack(u,enemy,.05);assert.equal(u.cooldown,UNITS.pike.rate/1.2);}
  if(faction===2){assert.equal(u.maxShield,baseShield*1.5);assert.equal(g.addUnit(0,'pike',620,1700).maxShield,u.maxShield);}
 }
});

test('distinct faction passives apply poison, lifesteal, precision and friendly-safe splash',()=>{
 const iron=quiet(),sniper=iron.addUnit(0,'ranger',700,1400),target=iron.addUnit(1,'pike',740,1400);target.hp=1000;target.maxHp=1000;let hp=target.hp;iron.attack(sniper,target,.05);const hit=hp-target.hp;sniper.cooldown=0;iron.attack(sniper,target,.05);hp=target.hp;sniper.cooldown=0;iron.attack(sniper,target,.05);assert(Math.abs((hp-target.hp)/hit-1.4)<.001);
 const swarm=quiet(1),leech=swarm.addUnit(0,'pike',700,1400),victim=swarm.addUnit(1,'pike',720,1400);leech.hp-=60;const injured=leech.hp;swarm.attack(leech,victim,.05);assert(leech.hp>injured);
 const poison=swarm.addUnit(0,'ranger',700,1250),poisoned=swarm.addUnit(1,'pike',740,1250);swarm.attack(poison,poisoned,.05);assert.equal(poisoned.poison.dps,3);const poisonedHp=poisoned.hp+poisoned.shield;poison.cooldown=100;poisoned.order={type:'move',x:1800,y:1700};advance(swarm,1);assert(poisoned.hp+poisoned.shield<poisonedHp);
 const cannon=iron.addUnit(0,'siege',600,1200),splashTarget=iron.addUnit(1,'pike',720,1200),second=iron.addUnit(1,'pike',750,1200),friendly=iron.addUnit(0,'pike',740,1210);const before=second.hp,allyHP=friendly.hp;iron.spatial=null;iron.attack(cannon,splashTarget,.05);assert(second.hp<before);assert.equal(friendly.hp,allyHP);
 assert(new Set(PROFILES.flatMap(profile=>Object.values(profile).map(p=>p.name))).size===21);
});

test('support heals allies and shield recovery improves with fieldcare; enemies are never healed',()=>{
 const g=quiet(2),healer=g.addUnit(0,'support',700,1400),friend=g.addUnit(0,'pike',730,1400),enemy=g.addUnit(1,'pike',750,1400);friend.hp-=50;friend.shield=0;enemy.hp-=50;const hp=friend.hp,foeHP=enemy.hp;g.heal(healer,1);assert.equal(friend.hp,hp+6);assert.equal(friend.shield,14);assert.equal(enemy.hp,foeHP);
 g.teams[0].tech.fieldcare=1;const before=friend.hp;g.heal(healer,1);assert.equal(friend.hp,before+8.4);assert.equal(healer.hp,healer.maxHp);
});

test('high ground has a ranged-only advantage and unit counters multiply correctly',()=>{
 const g=quiet();g.highgrounds=[{x:700,y:1400,rx:100,ry:100}];const ranger=g.addUnit(0,'ranger',700,1400),foe=g.addUnit(1,'pike',830,1400),pike=g.addUnit(0,'pike',700,1400);assert(Math.abs(g.damageMultiplier(ranger,foe)-1.25*1.4*1.12)<.0001);assert.equal(g.damageMultiplier(pike,foe),1.25);
 const titan=g.addUnit(1,'titan',900,1400),siege=g.addUnit(0,'siege',850,1400);assert.equal(g.damageMultiplier(siege,titan),1.25*1.5);
});

test('network commands cannot research another faction, ignore requirements or control allied factories',()=>{
 const g=quiet();assert.equal(applyCommand(g,0,{action:'research',id:'weapons'}).ok,false);readyTech(g,3);assert.equal(applyCommand(g,0,{action:'research',id:'frenzy'}).ok,false);assert.equal(applyCommand(g,0,{action:'research',id:'weapons'}).ok,true);assert.equal(applyCommand(g,0,{action:'cancelResearch',kind:'research'}).ok,true);
 const factory=g.own().find(e=>e.type==='foundry');assert.equal(applyCommand(g,0,{action:'rally',id:factory.id,x:700,y:1300}).ok,true);assert.equal(applyCommand(g,1,{action:'rally',id:factory.id,x:700,y:1300}).ok,false);
 g.research('armor');const view=perspective(g,1);assert.equal(view.teams[1].research,null);assert.equal(view.mapId,g.mapId);assert.deepEqual(Game.hydrate(g.serialize()).serialize(),g.serialize());
});
