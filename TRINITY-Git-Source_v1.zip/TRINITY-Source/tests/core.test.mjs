import assert from 'node:assert/strict';
import {Game,UNITS} from '../public/engine.js';
let checks=0;const check=(condition,message)=>{assert.ok(condition,message);checks++;};
const advance=(game,seconds)=>{for(let i=0;i<seconds*20&&!game.result;i++)game.update(.05);};
function quietGame(faction=0){const g=new Game({faction,difficulty:'easy'});for(const t of g.teams.slice(1)){t.nextTrain=9999;t.nextAttack=9999;t.buildTick=9999;}return g;}
for(let f=0;f<3;f++){
 const g=quietGame(f);const player=g.teams[0],hq=g.own().find(e=>e.type==='hq'),barracks=g.own().find(e=>e.type==='barracks');
 const before=player.ore,cost=g.cost('worker');check(g.train(hq.id,'worker').ok,'Worker queue accepts valid order');check(player.ore===before-cost.ore,'Correct faction production cost');check(g.population().used===10,'Queued unit reserves supply');g.cancelQueue(hq.id,0);check(player.ore===before,'Cancelled queue fully refunds resources');
 check(!g.train(barracks.id,'siege').ok,'Tier II unit is locked initially');advance(g,30);check(g.stats.gathered>120,'Workers mine and deliver resources');
 const worker=g.own().find(e=>e.type==='worker');const balance=player.ore;check(!g.build(worker.id,'supply',hq.x,hq.y).ok,'Overlapping building rejected');check(player.ore===balance,'Invalid placement does not charge resources');
 const built=g.build(worker.id,'academy',hq.x-100,hq.y+200);check(built.ok,'Academy can be placed on clear ground');advance(g,60);check(g.entity(built.id)?.progress===1,'Worker reaches and completes construction');
 player.ore=1000;player.crystal=1000;check(g.upgrade().ok,'Research begins after academy completes');advance(g,36);check(player.tier===2,'Research advances to tier II');check(g.train(barracks.id,'siege').ok,'Advanced unit can be produced');advance(g,24);check(g.own().some(e=>e.type==='siege'),'Siege unit spawned');
 const enemy=g.own(1).find(e=>e.type==='pike'),ally=g.own().find(e=>e.type==='pike');check(Math.abs(g.damageMultiplier(ally,enemy)-1.25)<.001,'All factions have cyclic advantage against next faction');
 const time=g.time;g.paused=true;g.update(.1);check(g.time===time,'Pause stops simulation time');g.paused=false;
 check(g.entities.every(e=>[e.x,e.y,e.hp].every(Number.isFinite)),'Finite entity state after economy and technology simulation');
}
{
 const g=quietGame(),u=g.addUnit(0,'pike',830,1000);g.issue([u.id],'move',{x:1510,y:1020});advance(g,35);check(Math.hypot(u.x-1510,u.y-1020)<60,'Pathfinding routes around central lake');
 const enemy=g.addUnit(1,'rider',1600,1600),pike=g.addUnit(0,'pike',1600,1570);check(Math.abs(g.damageMultiplier(pike,enemy)-1.75)<.001,'Faction and unit counter bonuses multiply');
 enemy.hp=1;g.issue([pike.id],'attack',enemy);advance(g,1);check(!g.entity(enemy.id),'Combat destroys enemy unit');check(g.stats.kills>=1,'Kill score increases');
}
{
 const g=quietGame();for(const team of [1,2]){const hq=g.own(team).find(e=>e.type==='hq');hq.hp=1;const attacker=g.addUnit(0,'siege',hq.x+140,hq.y);g.attack(attacker,hq,.05);}check(g.result==='victory','Destroying both enemy HQs wins');check(g.teams.slice(1).every(t=>!t.alive),'Eliminated factions cannot continue');
 const d=quietGame();const hq=d.own().find(e=>e.type==='hq');hq.hp=1;const attacker=d.addUnit(1,'siege',hq.x+140,hq.y);d.attack(attacker,hq,.05);check(d.result==='defeat','Losing player HQ ends in defeat');
}
{
 const g=new Game({faction:0,difficulty:'normal'});advance(g,600);check(g.result==='defeat','Unopposed AI reaches and defeats an idle player');check(g.teams.slice(1).some(t=>t.tier>=2),'AI advances its technology');check(g.teams.slice(1).some(t=>t.attacks>=2),'AI sends successive finite attack waves');
}
console.log(`${checks} core gameplay checks passed.`);
