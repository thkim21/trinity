import {DatabaseSync} from 'node:sqlite';
import {mkdirSync,readFileSync,readdirSync} from 'node:fs';
import {dirname} from 'node:path';

// D1-compatible adapter backed by the SQLite included with Node 24.
// Each batch completes its transaction before another request can run.
export class SQLiteDB {
 constructor(path,migrations){
  if(path!==':memory:')mkdirSync(dirname(path),{recursive:true});
  this.sql=new DatabaseSync(path);this.sql.exec('PRAGMA journal_mode=WAL; PRAGMA busy_timeout=5000; PRAGMA foreign_keys=ON;');
  this.sql.exec('CREATE TABLE IF NOT EXISTS local_migrations (name TEXT PRIMARY KEY, applied_at TEXT NOT NULL)');
  for(const name of readdirSync(migrations).filter(n=>n.endsWith('.sql')).sort()){
   if(this.sql.prepare('SELECT name FROM local_migrations WHERE name=?').get(name))continue;
   this.sql.exec('BEGIN IMMEDIATE');try{this.sql.exec(readFileSync(new URL(name,migrations),'utf8'));this.sql.prepare('INSERT INTO local_migrations VALUES (?,?)').run(name,new Date().toISOString());this.sql.exec('COMMIT');}catch(error){this.sql.exec('ROLLBACK');throw error;}
  }
 }
 withSession(){return this;}
 prepare(sql){
  const db=this.sql,statement={params:[],bind(...params){this.params=params;return this;},first(){return Promise.resolve(db.prepare(sql).get(...this.params)||null);},all(){return Promise.resolve({results:db.prepare(sql).all(...this.params)});},execute(){const result=db.prepare(sql).run(...this.params);return {success:true,meta:{changes:Number(result.changes),last_row_id:Number(result.lastInsertRowid)}};},run(){return Promise.resolve(this.execute());}};
  return statement;
 }
 batch(statements){this.sql.exec('BEGIN IMMEDIATE');try{const results=statements.map(statement=>statement.execute());this.sql.exec('COMMIT');return Promise.resolve(results);}catch(error){this.sql.exec('ROLLBACK');return Promise.reject(error);}}
 close(){this.sql.close();}
}
