import assets from '../.build/assets.mjs';
import {handleApi} from './rooms.js';
export default {
 async fetch(request,env){
 const url=new URL(request.url);
 if(url.pathname.startsWith('/api/')){const localFile=request.headers.get('Origin')==='null';if(request.method==='OPTIONS'&&localFile)return new Response(null,{status:204,headers:{'Access-Control-Allow-Origin':'null','Access-Control-Allow-Methods':'POST, OPTIONS','Access-Control-Allow-Headers':'Content-Type, Authorization','Access-Control-Max-Age':'600'}});const response=await handleApi(request,env);if(localFile){const headers=new Headers(response.headers);headers.set('Access-Control-Allow-Origin','null');headers.set('Vary','Origin');return new Response(response.body,{status:response.status,headers});}return response;}
 if(!['GET','HEAD'].includes(request.method))return new Response('Method not allowed',{status:405});
 const path=url.pathname==='/'?'/index.html':url.pathname;
 const asset=Object.hasOwn(assets,path)?assets[path]:null;
 if(!asset)return new Response('Not found',{status:404});
 const bytes=Uint8Array.from(atob(asset.body),c=>c.charCodeAt(0));
 const headers={'Content-Type':asset.mime,'Cache-Control':/\.(?:html|js|css|json|webmanifest)$/.test(path)?'no-cache':'public, max-age=3600','X-Content-Type-Options':'nosniff','Referrer-Policy':'same-origin'};
 if(path.startsWith('/downloads/'))headers['Content-Disposition']='attachment; filename="TRINITY.html"';
 if(path==='/sw.js')headers['Service-Worker-Allowed']='/';
 return new Response(request.method==='HEAD'?null:bytes,{headers});
 }
};
