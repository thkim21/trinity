import {Game,UNITS,BUILDINGS,WORLD} from '../public/engine.js';
import {DEFAULT_MAP,validMap} from '../public/maps.js';
export const PROTOCOL=4,DISCONNECT_MS=60000;
const HOUR=3600000;
class HttpError extends Error{constructor(status,message){super(message);this.status=status;}}
const json=(value,status=200)=>new Response(JSON.stringify(value),{status,headers:{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store','X-Content-Type-Options':'nosniff'}});
const tokenValid=t=>typeof t==='string'&&/^[a-f0-9]{64}$/.test(t);
const pinValid=p=>typeof p==='string'&&/^\d{6}$/.test(p);
const factionValid=f=>Number.isInteger(f)&&f>=0&&f<3;
const idValid=id=>Number.isSafeInteger(id)&&id>0;
const pointValid=p=>p&&Number.isFinite(p.x)&&Number.isFinite(p.y)&&p.x>=0&&p.y>=0&&p.x<=WORLD.w&&p.y<=WORLD.h;
async function hash(value){const bytes=await crypto.subtle.digest('SHA-256',new TextEncoder().encode(value));return Array.from(new Uint8Array(bytes),b=>b.toString(16).padStart(2,'0')).join('');}
function randomCode(){const alphabet='ABCDEFGHJKLMNPQRSTUVWXYZ23456789',bytes=crypto.getRandomValues(new Uint8Array(8));return Array.from(bytes,b=>alphabet[b%alphabet.length]).join('');}
export function visibleTo(game,team,target){return Number.isInteger(target.team)&&game.isAlly(target.team,team)||game.friendly(team).some(e=>Math.hypot(e.x-target.x,e.y-target.y)<(e.kind==='building'?360:e.type==='worker'?250:310));}
export function perspective(game,team){
 const state=game.serialize(),order=[team,...state.teams.map(t=>t.id).filter(i=>i!==team)],remap=new Map(order.map((id,index)=>[id,index])),friends=game.friendly(team);
 const visible=e=>Number.isInteger(e.team)&&game.isAlly(team,e.team)||friends.some(f=>Math.hypot(f.x-e.x,f.y-e.y)<(f.kind==='building'?360:f.type==='worker'?250:310));
 state.teams=order.map((i,j)=>({...state.teams[i],id:j,...(j?{ore:0,crystal:0,upgrade:null,research:null}:{})}));state.faction=state.teams[0].faction;
 state.entities=state.entities.filter(e=>e.hp>0&&visible(e)).map(e=>{delete e.path;delete e.pathGoal;delete e.pathUntil;delete e.pathRevision;delete e.pathIndex;if(e.team!==team){e.order={type:'idle'};e.queue=[];delete e.rally;}e.team=remap.get(e.team);return e;});
 state.effects=state.effects.filter(visible);state.events=state.events.filter(e=>(e.team??0)===team).map(e=>({...e,team:0}));state.teamStats=order.map((i,j)=>j?{kills:0,lost:0,gathered:0,trained:0}:state.teamStats[i]);state.stats=state.teamStats[0];state.winner=game.winner==null?null:remap.get(game.winner);
 const alliance=game.teams[team].alliance,teamAlive=game.teams.some(t=>t.alliance===alliance&&t.alive);state.result=game.result?(game.winnerAlliance===alliance?'victory':'defeat'):teamAlive?null:'defeat';state.paused=false;return state;
}
export function applyCommand(game,team,command){
 if(!command||typeof command!=='object'||game.result||!game.teams[team]?.alive)return {ok:false,message:'진행 중인 대전에서만 명령할 수 있습니다.'};
 const owned=id=>idValid(id)&&game.entity(id)?.team===team;
 switch(command.action){
 case 'train':if(!owned(command.id)||!Object.hasOwn(UNITS,command.unit))break;return game.train(command.id,command.unit);
 case 'cancel':if(!owned(command.id)||!Number.isInteger(command.index)||command.index<0||command.index>4)break;return {ok:game.cancelQueue(command.id,command.index)};
 case 'build':if(!owned(command.id)||!Object.hasOwn(BUILDINGS,command.building)||command.building==='hq'||!pointValid(command))break;return game.build(command.id,command.building,command.x,command.y);
 case 'upgrade':return game.upgrade(team);
 case 'research':return typeof command.id==='string'?game.research(command.id,team):{ok:false};
 case 'cancelResearch':return ['research','upgrade'].includes(command.kind)?game.cancelResearch(team,command.kind):{ok:false};
 case 'rally':if(!owned(command.id)||!['barracks','relay','foundry'].includes(game.entity(command.id).type)||!pointValid(command))break;game.entity(command.id).rally={x:command.x,y:command.y};return {ok:true};
 case 'order':{
 if(!Array.isArray(command.ids)||command.ids.length<1||command.ids.length>90||new Set(command.ids).size!==command.ids.length||!command.ids.every(owned))break;
 if(!['move','attackMove','attack','gather','stop','resumeBuild'].includes(command.order))break;
 if(['move','attackMove'].includes(command.order)&&!pointValid(command.target))break;
 if(['attack','gather','resumeBuild'].includes(command.order)&&!idValid(command.target?.id))break;
 if(command.order==='attack'){const enemy=game.entity(command.target.id);if(!enemy||game.isAlly(enemy.team,team)||!visibleTo(game,team,enemy))return {ok:false,message:'보이는 적을 선택하세요.'};}
 return {ok:game.issue(command.ids,command.order,command.target,team)>0};
 }
 }
 return {ok:false,message:'내 유닛과 건물에 유효한 명령을 내려주세요.'};
}const occupied=s=>s.kind==='ai'||s.kind==='human'&&!!s.tokenHash;
function slotsOf(room){return typeof room.slots==='string'?JSON.parse(room.slots):room.slots;}
function validTeams(slots,mode){if(mode==='ffa')return true;const counts={};for(const slot of slots.filter(occupied)){counts[slot.alliance]=(counts[slot.alliance]||0)+1;if(counts[slot.alliance]>4)return false;}return true;}
function invalidateReady(slots){for(const slot of slots)if(slot.kind==='human'&&slot.seat!==0)slot.ready=false;}
function summary(room,seat,now,game=null,errors=[]){const slots=slotsOf(room),me=slots[seat],player=game?.teams.find(t=>t.seat===seat);return {protocol:PROTOCOL,code:room.code,status:room.status,mapId:room.map_id||DEFAULT_MAP,mode:room.mode,difficulty:room.difficulty,revision:room.revision,me:seat,ack:me?.ack||0,players:slots.map(s=>({seat:s.seat,kind:s.kind,faction:s.faction,alliance:s.alliance,ready:s.kind==='ai'||s.ready,present:occupied(s),connected:s.kind==='ai'||!!s.tokenHash&&now-s.seen<10000,awayMs:s.kind==='human'&&s.tokenHash?Math.max(0,now-s.seen):0,alive:game?.teams.find(t=>t.seat===s.seat)?.alive??true})),expiresAt:room.expires_at,disconnectGraceMs:DISCONNECT_MS,reason:room.reason,errors,game:game&&player?perspective(game,player.id):null};}
async function save(db,room,revision){const result=await db.prepare('UPDATE rooms SET expires_at=?,slots=?,mode=?,map_id=?,difficulty=?,status=?,revision=?,game=?,sim_at=?,reason=? WHERE code=? AND revision=?').bind(room.expires_at,JSON.stringify(slotsOf(room)),room.mode,room.map_id||DEFAULT_MAP,room.difficulty,room.status,revision+1,room.game,room.sim_at,room.reason,room.code,revision).run();if(result.meta.changes){room.revision=revision+1;return true;}return false;}
export async function handleApi(request,env,{now=Date.now}={}){
 try{
 if(request.method!=='POST')throw new HttpError(405,'POST 요청이 필요합니다.');const url=new URL(request.url),origin=request.headers.get('Origin');if(origin&&origin!=='null'&&origin!==url.origin)throw new HttpError(403,'게임 주소 또는 내려받은 게임에서 접속하세요.');
 if(!env.DB)throw new HttpError(503,'대전 서버를 준비하고 있습니다. 잠시 후 다시 시도하세요.');const db=env.DB.withSession?env.DB.withSession('first-primary'):env.DB;
 if(Number(request.headers.get('Content-Length')||0)>24000)throw new HttpError(413,'명령이 너무 큽니다.');const text=await request.text();if(text.length>24000)throw new HttpError(413,'명령이 너무 큽니다.');let body;try{body=JSON.parse(text);}catch{throw new HttpError(400,'올바른 요청이 아닙니다.');}if(!body||Array.isArray(body)||typeof body!=='object')throw new HttpError(400,'올바른 요청이 아닙니다.');if(body.protocol!==PROTOCOL)throw new HttpError(409,'게임이 업데이트되었습니다. 모든 게임 창을 닫고 다시 열어주세요.');const timestamp=now();
 if(url.pathname==='/api/rooms'){
 if(!tokenValid(body.token)||!factionValid(body.faction)||!pinValid(body.pin)||body.mapId!==undefined&&!validMap(body.mapId))throw new HttpError(400,'종족과 입장번호를 확인하세요.');const hostHash=await hash(body.token);const existing=await db.prepare('SELECT * FROM rooms WHERE host_hash=? AND expires_at>?').bind(hostHash,timestamp).first();if(existing&&existing.status!=='closed')return json(summary(existing,0,timestamp,existing.game?Game.hydrate(JSON.parse(existing.game)):null));
 const bucket=await hash((request.headers.get('CF-Connecting-IP')||'anonymous')+':'+Math.floor(timestamp/HOUR));const count=await db.prepare('SELECT COUNT(*) AS count FROM rooms WHERE creator_bucket=? AND created_at>?').bind(bucket,timestamp-60000).first();if(count.count>=8)throw new HttpError(429,'방 생성이 많습니다. 1분 후 다시 시도하세요.');
 await db.batch([db.prepare('DELETE FROM rooms WHERE code IN (SELECT code FROM rooms WHERE expires_at<? LIMIT 50)').bind(timestamp),db.prepare('DELETE FROM join_limits WHERE bucket IN (SELECT bucket FROM join_limits WHERE expires_at<? LIMIT 100)').bind(timestamp)]);
 for(let attempt=0;attempt<5;attempt++){
 const code=randomCode(),pinHash=await hash(code+':'+body.pin),slots=Array.from({length:8},(_,i)=>({seat:i,kind:i===0?'human':'open',tokenHash:i===0?hostHash:null,faction:i===0?body.faction:i%3,alliance:i%2,ready:i===0,seen:i===0?timestamp:0,ack:0}));
 const room={code,pin_hash:pinHash,created_at:timestamp,expires_at:timestamp+30*60000,host_hash:hostHash,slots,map_id:body.mapId||DEFAULT_MAP,mode:'ffa',difficulty:'normal',status:'waiting',revision:0,game:null,sim_at:timestamp,creator_bucket:bucket,reason:null};
 const result=await db.prepare('INSERT OR IGNORE INTO rooms (code,pin_hash,created_at,expires_at,host_hash,slots,sim_at,creator_bucket,map_id) VALUES (?,?,?,?,?,?,?,?,?)').bind(code,pinHash,timestamp,room.expires_at,hostHash,JSON.stringify(slots),timestamp,bucket,room.map_id).run();if(result.meta.changes)return json(summary(room,0,timestamp),201);
 }
 throw new HttpError(503,'방 생성에 실패했습니다. 다시 시도하세요.');
 }
 const match=url.pathname.match(/^\/api\/rooms\/([A-HJ-NP-Z2-9]{8})\/(join|sync|ready|faction|config|start|leave)$/);if(!match)throw new HttpError(404,'8자리 방 코드를 확인하세요.');const [,code,operation]=match;
 const token=operation==='join'?body.token:request.headers.get('Authorization')?.replace(/^Bearer /,'');if(!tokenValid(token))throw new HttpError(401,'방 참가 정보가 없습니다. 다시 참가해 주세요.');const tokenHash=await hash(token);
 for(let attempt=0;attempt<6;attempt++){
 const room=await db.prepare('SELECT * FROM rooms WHERE code=?').bind(code).first();if(!room||room.expires_at<=timestamp)throw new HttpError(404,'없는 방이거나 만료된 방 코드입니다.');const revision=room.revision,slots=slotsOf(room);room.slots=slots;let seat=slots.findIndex(s=>s.tokenHash===tokenHash);
 if(operation==='join'&&seat<0){
 if(room.status!=='waiting')throw new HttpError(409,'이미 시작했거나 종료된 방입니다.');if(!pinValid(body.pin)||!factionValid(body.faction))throw new HttpError(400,'6자리 입장번호와 종족을 확인하세요.');
 const attemptKey=await hash(code+':'+(request.headers.get('CF-Connecting-IP')||'anonymous')+':'+Math.floor(timestamp/120000));const attempts=await db.prepare('SELECT failures FROM join_limits WHERE bucket=?').bind(attemptKey).first();if(attempts?.failures>=10)throw new HttpError(429,'입장번호 입력이 여러 번 틀렸습니다. 2분 후 다시 시도하세요.');
 if(await hash(code+':'+body.pin)!==room.pin_hash){await db.prepare('INSERT INTO join_limits (bucket,failures,expires_at) VALUES (?,1,?) ON CONFLICT(bucket) DO UPDATE SET failures=failures+1').bind(attemptKey,timestamp+240000).run();throw new HttpError(403,'입장번호가 맞지 않습니다. 방장에게 확인하세요.');}
 seat=slots.findIndex(s=>s.kind==='open');if(seat<0)throw new HttpError(409,'빈 참가 자리가 없습니다. 방장에게 자리를 열어 달라고 요청하세요.');
 const slot=slots[seat];Object.assign(slot,{kind:'human',tokenHash,faction:body.faction,ready:false,seen:timestamp,ack:0});if(room.mode==='teams'&&!validTeams(slots,room.mode)){for(let alliance=0;alliance<4;alliance++){slot.alliance=alliance;if(validTeams(slots,room.mode))break;}}invalidateReady(slots);
 }else if(seat<0)throw new HttpError(403,'이 방의 참가자만 조작할 수 있습니다.');
 if(room.status==='closed')throw new HttpError(410,'방장이 대기실을 닫았습니다.');
 const beforeSeen=slots.map(s=>s.seen);slots[seat].seen=timestamp;let game=room.game?Game.hydrate(JSON.parse(room.game)):null;const errors=[];
 if(room.status==='playing'&&game){
 for(const slot of slots){const player=game.teams.find(t=>t.seat===slot.seat);if(slot.kind==='human'&&slot.tokenHash&&player?.alive&&timestamp-beforeSeen[slot.seat]>DISCONNECT_MS){game.forfeit(player.id);room.reason='disconnect';}}
 const gap=Math.max(0,timestamp-room.sim_at),ticks=Math.floor(Math.min(gap,2000)/50);for(let i=0;i<ticks&&!game.result;i++)game.update(.05);room.sim_at=gap>2000?timestamp:room.sim_at+ticks*50;
 }
 if(operation==='faction'){if(room.status!=='waiting'||!factionValid(body.faction))throw new HttpError(400,'대기실에서 종족을 선택하세요.');slots[seat].faction=body.faction;if(seat!==0)slots[seat].ready=false;}
 if(operation==='ready'){if(room.status!=='waiting'||typeof body.ready!=='boolean')throw new HttpError(400,'대기실에서 준비 상태를 변경하세요.');slots[seat].ready=body.ready;}
 if(operation==='config'){
 if(seat!==0||room.status!=='waiting')throw new HttpError(403,'대기실 설정은 방장만 변경할 수 있습니다.');
 if(body.mapId!==undefined){if(!validMap(body.mapId))throw new HttpError(400,'목록의 맵을 선택하세요.');room.map_id=body.mapId;}
 if(body.mode!==undefined){if(!['ffa','teams'].includes(body.mode))throw new HttpError(400,'개인전 또는 팀전을 선택하세요.');room.mode=body.mode;}
 if(body.difficulty!==undefined){if(!['easy','normal','hard'].includes(body.difficulty))throw new HttpError(400,'AI 난이도를 확인하세요.');room.difficulty=body.difficulty;}
 if(body.slot!==undefined){if(!Number.isInteger(body.slot)||body.slot<0||body.slot>7)throw new HttpError(400,'자리를 확인하세요.');const slot=slots[body.slot];
 if(body.kind!==undefined){if(slot.kind==='human'&&slot.tokenHash||!['open','ai','closed'].includes(body.kind))throw new HttpError(400,'참가 중인 사용자의 자리는 바꿀 수 없습니다.');slot.kind=body.kind;slot.tokenHash=null;slot.ready=body.kind==='ai';slot.ack=0;}
 if(body.faction!==undefined){if(!factionValid(body.faction))throw new HttpError(400,'종족을 확인하세요.');slot.faction=body.faction;}
 if(body.alliance!==undefined){if(!Number.isInteger(body.alliance)||body.alliance<0||body.alliance>3)throw new HttpError(400,'A~D 팀 중 선택하세요.');slot.alliance=body.alliance;}
 }
 if(!validTeams(slots,room.mode))throw new HttpError(400,'한 팀에는 최대 4명까지만 참가할 수 있습니다.');invalidateReady(slots);
 }
 if(operation==='start'){
 if(seat!==0)throw new HttpError(403,'방장만 대전을 시작할 수 있습니다.');
 if(room.status==='waiting'){
 const active=slots.filter(occupied);if(active.length<2)throw new HttpError(409,'상대 사용자 또는 AI가 한 명 이상 필요합니다.');if(active.some(s=>s.kind==='human'&&(!s.ready||timestamp-s.seen>10000)))throw new HttpError(409,'모든 사용자가 연결하고 준비를 완료해야 합니다.');if(!validTeams(slots,room.mode))throw new HttpError(409,'한 팀의 최대 인원은 4명입니다.');
 const players=active.map(s=>({seat:s.seat,kind:s.kind,faction:s.faction,alliance:room.mode==='ffa'?s.seat:s.alliance}));if(new Set(players.map(p=>p.alliance)).size<2)throw new HttpError(409,'서로 다른 팀에 상대가 있어야 합니다.');
 game=new Game({players,mapId:room.map_id||DEFAULT_MAP,mode:room.mode,difficulty:room.difficulty,seed:crypto.getRandomValues(new Uint32Array(1))[0]});room.status='playing';room.sim_at=timestamp;room.expires_at=timestamp+3*HOUR;for(const slot of active)slot.seen=timestamp;
 }
 }
 if(operation==='sync'&&body.commands!==undefined){
 if(!Array.isArray(body.commands)||body.commands.length>24)throw new HttpError(400,'명령을 나누어 전송하세요.');const player=game?.teams.find(t=>t.seat===seat),slot=slots[seat];
 for(const command of body.commands){if(!Number.isSafeInteger(command?.seq)||command.seq<1)throw new HttpError(400,'명령 순서를 확인하세요.');if(command.seq<=slot.ack)continue;if(command.seq!==slot.ack+1)break;const outcome=game&&player&&room.status==='playing'?applyCommand(game,player.id,command):{ok:false,message:'진행 중인 대전이 아닙니다.'};slot.ack=command.seq;if(!outcome.ok)errors.push(outcome.message||'명령을 실행할 수 없습니다.');}
 }
 if(operation==='leave'){
 if(room.status==='playing'&&game&&!game.result){const player=game.teams.find(t=>t.seat===seat);if(player)game.forfeit(player.id);room.reason='forfeit';}
 else if(room.status==='waiting'){if(seat===0){room.status='closed';room.expires_at=timestamp+60000;}else{Object.assign(slots[seat],{kind:'open',tokenHash:null,ready:false,seen:0,ack:0});invalidateReady(slots);}}
 }
 if(game?.result){room.status='finished';room.expires_at=Math.min(room.expires_at,timestamp+15*60000);}if(game)room.game=JSON.stringify(game.serialize());if(await save(db,room,revision))return json(summary(room,seat,timestamp,game,errors));
 }
 throw new HttpError(503,'다른 참가자의 명령과 동기화 중입니다. 다시 연결합니다.');
 }catch(error){if(error instanceof HttpError)return json({error:error.message},error.status);console.error('Multiplayer operation failed:',error?.message);return json({error:'대전 서버 연결에 문제가 생겼습니다. 잠시 후 다시 시도하세요.'},503);}
}
