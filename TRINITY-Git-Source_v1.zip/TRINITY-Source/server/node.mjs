import http from 'node:http';
import {resolve} from 'node:path';
import {isIP} from 'node:net';
import worker from './worker.mjs';
import {SQLiteDB} from './sqlite.mjs';

const port=Number(process.env.PORT||3000),host=process.env.HOST||'0.0.0.0';
if(!Number.isInteger(port)||port<0||port>65535)throw new Error('Invalid PORT');
const publicOrigin=process.env.PUBLIC_ORIGIN?new URL(process.env.PUBLIC_ORIGIN).origin:null;
const trustProxy=process.env.TRUST_PROXY==='1';
const DB=new SQLiteDB(process.env.DB_PATH||resolve('data/trinity.sqlite'),new URL('../drizzle/',import.meta.url));
const server=http.createServer(async(req,res)=>{
 try{
  // Set PUBLIC_ORIGIN to the external URL when an HTTPS proxy fronts this server.
  const origin=publicOrigin||'http://'+(req.headers.host||'localhost:'+port);
  const url=new URL(req.url,origin);if(url.origin!==origin){res.writeHead(400);res.end('Bad request');return;}
  if(url.pathname==='/healthz'&&['GET','HEAD'].includes(req.method)){res.writeHead(200,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end(req.method==='HEAD'?undefined:'{"ok":true}');return;}
  let length=0;const chunks=[];
  if(Number(req.headers['content-length']||0)>24000){res.writeHead(413,{'Connection':'close'});res.end('Request too large');return;}
  for await(const chunk of req){length+=chunk.length;if(length>24000){res.writeHead(413,{'Connection':'close'});res.end('Request too large');return;}chunks.push(chunk);}
  const headers=new Headers();for(const [key,value] of Object.entries(req.headers))if(value!==undefined)headers.set(key,Array.isArray(value)?value.join(','):value);
  const forwarded=String(req.headers['x-forwarded-for']||'').split(',').at(-1).trim();
  headers.set('CF-Connecting-IP',trustProxy&&isIP(forwarded)?forwarded:req.socket.remoteAddress||'unknown');
  const request=new Request(url,{method:req.method,headers,...(!['GET','HEAD'].includes(req.method)?{body:Buffer.concat(chunks)}:{})});
  const response=await worker.fetch(request,{DB});
  res.writeHead(response.status,Object.fromEntries(response.headers));res.end(Buffer.from(await response.arrayBuffer()));
 }catch(error){console.error('Request failed:',error.message);if(!res.headersSent)res.writeHead(500,{'Content-Type':'application/json','Cache-Control':'no-store'});res.end('{"error":"서버 요청을 처리하지 못했습니다."}');}
});
server.requestTimeout=15000;server.headersTimeout=10000;
server.listen(port,host,()=>console.log('TRINITY server ready on port '+server.address().port));
let closing=false;function shutdown(){if(closing)return;closing=true;server.close(()=>{DB.close();process.exit(0);});server.closeIdleConnections();const timer=setTimeout(()=>{server.closeAllConnections();DB.close();process.exit(0);},8000);timer.unref();}
process.on('SIGINT',shutdown);process.on('SIGTERM',shutdown);
