import fs from 'node:fs/promises';
import {build} from 'esbuild';
const mime={'.html':'text/html; charset=utf-8','.js':'text/javascript; charset=utf-8','.css':'text/css; charset=utf-8','.json':'application/json','.webmanifest':'application/manifest+json','.webp':'image/webp','.png':'image/png','.svg':'image/svg+xml'};
await fs.mkdir('.build',{recursive:true});
const standalone=await build({entryPoints:['public/main.js'],bundle:true,format:'iife',platform:'browser',target:'es2022',minify:true,write:false});
const css=(await fs.readFile('public/style.css','utf8')).replace(/@import\s+url\([^)]*\)\s*;/g,'');
const art=await fs.readFile('public/art/units.webp');
const script='globalThis.TRINITY_MODE="offline";globalThis.TRINITY_ART="data:image/webp;base64,'+art.toString('base64')+'";'+standalone.outputFiles[0].text.replace(/<\/script/gi,'<\\/script');
const html='<!doctype html><html lang="ko"><head><meta charset="UTF-8"><meta http-equiv="Content-Security-Policy" content="default-src \'none\'; script-src \'unsafe-inline\'; style-src \'unsafe-inline\'; img-src data:; connect-src \'none\'; base-uri \'none\'; form-action \'none\'"><meta name="viewport" content="width=device-width,initial-scale=1,viewport-fit=cover"><meta name="theme-color" content="#10191c"><title>TRINITY FRONTIER - 오프라인 포터블</title><style>'+css+'</style></head><body><div id="app"></div><script>'+script+'</script></body></html>';
await fs.mkdir('public/downloads',{recursive:true});await fs.writeFile('public/downloads/TRINITY.html',html);
// GitHub Pages can serve the prebuilt docs folder directly, including subpaths.
await fs.rm('docs',{recursive:true,force:true});await fs.cp('public','docs',{recursive:true});
const index=await fs.readFile('public/index.html','utf8');
await fs.writeFile('docs/index.html',index.replace('<body>','<body><script>globalThis.TRINITY_MODE="static";</script>'));
await fs.writeFile('docs/.nojekyll','');
const manifest=JSON.parse(await fs.readFile('docs/manifest.webmanifest','utf8'));manifest.description='세 종족과 16개 맵의 오프라인 AI 실시간 전략 게임';await fs.writeFile('docs/manifest.webmanifest',JSON.stringify(manifest,null,2));
const assets={};async function collect(dir,base=''){for(const item of await fs.readdir(dir,{withFileTypes:true})){if(item.isDirectory())await collect(dir+'/'+item.name,base+item.name+'/');else{const path=base+item.name,bytes=await fs.readFile(dir+'/'+item.name);assets['/'+path]={body:bytes.toString('base64'),mime:mime['.'+item.name.split('.').at(-1)]||'application/octet-stream'};}}}
await collect('public');await fs.writeFile('.build/assets.mjs','export default '+JSON.stringify(assets)+';');
await fs.rm('dist',{recursive:true,force:true});await fs.mkdir('dist/server',{recursive:true});
await build({entryPoints:['server/worker.js'],bundle:true,format:'esm',platform:'browser',target:'es2022',outfile:'dist/server/worker.mjs',minify:true});
for(const file of ['node.mjs','sqlite.mjs'])await fs.copyFile('server/'+file,'dist/server/'+file);
await fs.cp('drizzle','dist/drizzle',{recursive:true});
console.log(`Built: public/downloads/TRINITY.html (offline), docs/ (Pages), dist/ (multiplayer server; ${Object.keys(assets).length} assets).`);
